<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Enrollment extends Model

{
	protected $table ='enrollments';
    protected $fillable = ['student_id','course_id','school_year_id','teacher_id','scholarship_id'];

    protected $dates = ['create_at','update_at'];

    public function student(){

    	return $this->belongsTo(Student::class);
    }

    public function course(){

    	return $this->belongsTo(Course::class);
    }

    public function schoolyear(){

    	return $this->belongsTo(SchoolYear::class);
    }

    public function teacher(){

        return $this->belongsTo(Teacher::class);

    }

    public function scholarship(){

        return $this->belongsTo(Scholarship::class);
    }

    public function reservation(){

        return $this->belongsTo(Reservation::class);
    }

    public function school_year(){

        return $this->belongsTo(School_Year::class);
    }
}

