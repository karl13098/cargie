<?php

namespace App\Http\Controllers;
use App\Student;
use App\Reservation;
use App\Enrollment;
use App\Scholarship;
use App\Course;
use App\Teacher;
use App\School_Year;
use App\Semester;
use Illuminate\Http\Request;

class EnrollmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $enrollments = Enrollment::get();
        return view('enrollments.index',compact('enrollments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $reservations = Reservation::get();
        return view('enrollments.create',compact('reservations'));

        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $data = $request->validate([

            'student'=>'required|unique:students,id',
            'course'=>'required',
            'scholarship'=>'required',
            'school_year'=>'required'
           
            
       ]);

       $enrollment = Enrollment::create([
            'student_id' => $data['student'],
            'course_id' => $data['course'],
            'scholarship_id' => $data['scholarship'],
            'school_year_id' => $data['school_year']
       ]);

       return redirect()->route('students.index',$data['student']);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $enrollment = Enrollment::find($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
