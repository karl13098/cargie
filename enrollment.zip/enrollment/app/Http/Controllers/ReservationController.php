<?php

namespace App\Http\Controllers;

use App\Schedule;
use App\Enrollment;
use App\Reservation;
use App\Student;
use App\Course;
use App\Scholarship;
use App\School_Year;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Session;
Session_start();

class ReservationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $schedules = Schedule::get();
        $reservations = Reservation::get();
        $school_years = School_Year::get();

       
        return view('reservations.index',compact('reservations','school_years','schedules'));

        
    }
     public function search(Request $request)
    {
        $reservation = Reservation::find($request->input('id'));
        return view('reservations.search', compact('reservation'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $students = Student::get();
        $school_years = School_Year::get();
        $reservation = Reservation::find($id);
        return view('reservations.show',compact('reservation','school_years','students'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $reservation = Reservation::find($id);

        $courses = Course::get();
        $scholarships = Scholarship::get();

        return view('reservations.edit',compact('reservation','courses','scholarships'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       
       $reservation = Reservation::find($id);

       $courses = Course::get();
       $scholarships = Scholarship::get();

       $reservation->course_id = $request->get('course');
       $reservation->scholarship_id = $request->get('scholarship');

       $reservation->save();
        return redirect()->route('reservations.index')
                        ->with('success','Reservation updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        /*$reservation = Reservation::find($id);
        $registration
        'student_id'=>$enrollment->student_id,
        'course_id' =>$enrollment->course_id,
        'scholarship_id' => $enrollment->scholarship_id,
        'school_year_id' => $enrollment->school_year_id
       ]);
        $reservation->delete();

       return redirect()->route('students.index',compact('student','course','scholarship','school_year'));*/

       $reservation = Reservation::find($id);
      
        
       $reservation->delete();

       return redirect()->route('reservations.index')
                       ->with('success','Reservation deleted successfully');
  }
}
