<?php

namespace App\Http\Controllers;

use App\Scholarship;

use Illuminate\Http\Request;

class ScholarshipController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $scholarships = Scholarship::get();

        return view('scholarships.index',compact('scholarships'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $scholarships = Scholarship::get();

        return view('scholarships.create',compact('scholarships'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $request->validate([
            'name'=>'required',
            'description'=>'nullable'
        ]);

        $scholarship = Scholarship::create($request->all());

        return redirect()->route('scholarships.index')
                        ->with('success','New scholarship created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $scholarship = Scholarship::find($id);

        return view('scholarships.show',compact('scholarship'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $scholarship = Scholarship::find($id);

        return view('scholarships.edit',compact('scholarship'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $request->validate([
            'name'=>'required',
            'description'=>'nullable'
        ]);


         $scholarship = Scholarship::find($id);
         $scholarship->name = $request->get('name');
         $scholarship->description = $request->get('description');
         $scholarship->save();      

       

        return redirect()->route('scholarships.index')
                        ->with('success','Scholarship updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $scholarship = Scholarship::find($id);
        $scholarship->delete();
        return redirect()->route('scholarships.index')
                        ->with('success','Scholarship deleted successfully');
    }
}
