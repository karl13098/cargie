<?php

namespace App\Http\Controllers;

use App\School_Year;
use Illuminate\Http\Request;

class School_YearController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $school_years = School_Year::get();

        return view('school_years.index',compact('school_years'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        

        return view('school_years.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'year'=>'required',
            'default'=>'required'
        ]);

        $school_year = School_Year::create($request->all());

        return redirect()->route('school_years.index')
                        ->with('success','New school year successfully created');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\School_Year  $School_Year
     * @return \Illuminate\Http\Response
     */
    public function show(School_Year $school_year)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\School_Year  $School_Year
     * @return \Illuminate\Http\Response
     */
    public function edit(School_Year $school_year)
    {
        return view('school_years.edit',compact('school_year'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\School_Year  $School_Year
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, School_Year $school_year)
    {
         $request->validate([
            'year'=>'required',
            'default'=>'required'
        ]);

         
         $school_year->year = $request->get('year');
         $school_year->default = $request->get('default');
         $school_year->save();

         return redirect()->route('school_years.index')
                        ->with('success','School year updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\School_Year  $School_Year
     * @return \Illuminate\Http\Response
     */
    public function destroy(School_Year $school_year)
    {
         $school_year->delete();
        return redirect()->route('school_years.index')
                        ->with('success','School year successfully deleted');
    }
}
