<?php

namespace App\Http\Controllers;
use App\School_Year;
use App\Teacher;
use App\Section;
use App\Course;
use Illuminate\Http\Request;

class SectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sections = Section::get();

        return view('sections.index',compact('sections'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $teachers = Teacher::get();
       

        return view('sections.create',compact('teachers'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name'=>'required',
            'description'=>'nullable',
            'teacher'=>'required|unique:sections,teacher_id'
            
        ]);

        $section = Section::create([

            'name'=>$data['name'],
            'description'=>$data['description'],
            'teacher_id'=>$data['teacher']
        ]);

        return redirect()->route('sections.index')
                        ->with('success','New section created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Section  $section
     * @return \Illuminate\Http\Response
     */
    public function show(Section $section)
    {
        return view('sections.show',compact('section'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Section  $section
     * @return \Illuminate\Http\Response
     */
    public function edit(Section $section )
    {
        
        $teachers = Teacher::get();
        return view('sections.edit',compact('section','teachers'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Section  $section
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Section $section)
    {
        $data = $request->validate([
            'name'=>'required',
            'description'=>'nullable',
             'teacher'=>'required|unique:sections,teacher_id',
           
        ]);

        $section->update([

            'name'=>$data['name'],
            'description'=>$data['description'],
            'teacher_id'=>$data['teacher']

        ]);

        return redirect()->route('sections.index')
                        ->with('success','Section updated successfully');


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Section  $section
     * @return \Illuminate\Http\Response
     */
    public function destroy(Section $section)
    {
        $section->delete();
        return redirect()->route('sections.index')
                        ->with('success','Section successfully deleted');
    }
}
