<?php

namespace App\Http\Controllers;
use App\Enrollment;
use App\Reservation;
use App\Student;
use App\Course;
use App\Scholarship;
use App\Schedule;
use App\Studentschedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;



class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        
        $studentschedules = Studentschedule::get();
        $schedules = Schedule::get();
        $students = Student::whereHas('enrollments')->get();


        return view('students.index',compact('students','schedules','studentschedules'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   

        $courses = Course::get();
        $scholarships = Scholarship::get();
        return view('students.create',compact('courses','scholarships'));
    }

   

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {



             $request->validate([
            'firstname'=>'required',
            'lastname'=>'required',
            'middlename'=>'required',
            
            'gender'=>'required',
            'birthdate'=>'required',
            'nationality'=>'required',
            
            'birthplaceprovince'=>'required',
            'birthplacecity'=>'required',
            'civilstatus'=>'required',
            'employment'=>'required',
            'street'=>'required',
            'barangay'=>'required',
            
            'province'=>'required',
            'city'=>'required',
            'email'=>'required|email',
            'mobile'=>'nullable|max:11',
            'telephone'=>'nullable',
            'parentguardianname'=>'required',
            'mailingaddress'=>'required',
            'education'=>'required',
            'course_id'=>'required',
            'scholarship_id'=>'nullable'

        ]);

        $student = Student::create($request->all());

        $reservation = Reservation::create([
            'student_id' => $student->id,
            'course_id' => $request->course_id,
            'scholarship_id'=>$request->scholarship_id
        ]);
        return redirect()->route('reservations.index')
                        ->with('success','New reservation created successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {   
        $studentschedules = Studentschedule::get();
        $schedules = Schedule::get();
        $student = Student::find($id);
        return view('students.show',compact('student','studentschedules','schedules'));
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   

        $student = Student::find($id);
        return view('students.edit',compact('student'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
                         $request->validate([
            'firstname'=>'required',
            'lastname'=>'required',
            'middlename'=>'required',
            
            'gender'=>'required',
            'birthdate'=>'required',
            'nationality'=>'required',
            
            'birthplaceprovince'=>'required',
            'birthplacecity'=>'required',
            'civilstatus'=>'required',
            'employment'=>'required',
            'street'=>'required',
            'barangay'=>'required',
            
            'province'=>'required',
            'city'=>'required',
            'email'=>'required|email',
            'mobile'=>'nullable|max:11',
            'telephone'=>'nullable',
            'parentguardianname'=>'required',
            'mailingaddress'=>'required',
            'education'=>'required',
           
            

        ]);

       
    

        $students = Student::find($id);
        $students->firstname = $request->get('firstname');
        $students->lastname = $request->get('lastname');
        $students->middlename = $request->get('middlename');
        $students->gender = $request->get('gender');
        $students->birthdate = $request->get('birthdate');
        $students->nationality = $request->get('nationality');
        
        $students->birthplacecity = $request->get('birthplacecity');
        $students->civilstatus = $request->get('civilstatus');
        $students->employment = $request->get('employment');
        $students->street = $request->get('street');
        $students->barangay = $request->get('barangay');
        

        
        $students->province = $request->get('province');
        $students->city = $request->get('city');

        $students->email = $request->get('email');
        $students->mobile = $request->get('mobile');
        $students->telephone = $request->get('telephone');
        $students->parentguardianname = $request->get('parentguardianname');
        $students->mailingaddress = $request->get('mailingaddress');
        $students->education = $request->get('education');
       

        $students->save();

        return redirect()->route('students.index')
                        ->with('success','students updated successfully');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $student = Student::find($id);
        
        $student->delete();
        return redirect()->route('students.index')
                        ->with('success','Student successfully deleted');
    }


   
    
    
}
