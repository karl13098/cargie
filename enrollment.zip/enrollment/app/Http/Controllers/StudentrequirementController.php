<?php

namespace App\Http\Controllers;

use App\Enrollment;
use App\Student;
use App\Studentrequirement;
use Illuminate\Http\Request;

class StudentrequirementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $students = Student::get();
        $studentrequirements = Studentrequirement::get();
        $enrollments = Enrollment::get();

        return view('studentrequirements.index',compact('students','studentrequirements','enrollments'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $students = Student::get();

        return view('studentrequirements.create',compact('students'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'student'=>'required',
            'name'=>'nullable'
        ]);

        $studentrequirement = Studentrequirement::create([
            'student_id'=>$data['student'],
            'name'=>$data['name']
        ]);

        return redirect()->route('studentrequirements.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Studentrequirement  $studentrequirement
     * @return \Illuminate\Http\Response
     */
    public function show(Studentrequirement $studentrequirement)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Studentrequirement  $studentrequirement
     * @return \Illuminate\Http\Response
     */
    public function edit(Studentrequirement $studentrequirement)
    {
        $students = Student::get();
        return view('studentrequirements.edit',compact('studentrequirement','students'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Studentrequirement  $studentrequirement
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Studentrequirement $studentrequirement)
    {
         $data = $request->validate([
            'student'=>'required',
            'name'=>'nullable'
        ]);


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Studentrequirement  $studentrequirement
     * @return \Illuminate\Http\Response
     */
    public function destroy(Studentrequirement $studentrequirement)
    {
        $studentrequirement->delete();

      
    }
}
