<?php

namespace App\Http\Controllers;

use App\Course;
use App\Student;
use App\Schedule;
use App\Studentschedule;
use App\Enrollment;
use Illuminate\Http\Request;

class StudentscheduleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $students = Student::get();
        $schedules = Schedule::get();
        $studentschedules = Studentschedule::get();
        return view('studentschedules.index',compact('studentschedules','schedules','students'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $students = Student::get();
        $schedules = Schedule::get();

        return view('studentschedules.create',compact('students','schedules'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'student'=>'required|unique:studentschedules,student_id',
            'schedule'=>'required'

        ]);


        $studentschedule = Studentschedule::create([

            'student_id' => $data['student'],
            'schedule_id' => $data['schedule']
        ]);

        return redirect()->route('studentschedules.index')
                        ->with('success','Student schedule created successfully');


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Studentschedule  $studentschedule
     * @return \Illuminate\Http\Response
     */
    public function show(Studentschedule $studentschedule)
    {
        $courses = Course::get();
        $students = Student::get();
        $schedules = Schedule::get();
        return view('studentschedules.show',compact('studentschedule','students','schedules','courses'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Studentschedule  $studentschedule
     * @return \Illuminate\Http\Response
     */
    public function edit(Studentschedule $studentschedule)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Studentschedule  $studentschedule
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Studentschedule $studentschedule)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Studentschedule  $studentschedule
     * @return \Illuminate\Http\Response
     */
    public function destroy(Studentschedule $studentschedule)
    {
        $studentschedule->delete();

          return redirect()->route('studentschedules.index')
                        ->with('success','Student schedule deleted successfully');
    }
}
