<?php

namespace App\Http\Controllers;

use App\Teacher;
use Illuminate\Http\Request;

class TeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $teachers = Teacher::get();
        return view('teacher.index',compact('teachers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('teacher.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'firstname'=>'required',
            'middlename'=>'required',
            'lastname'=>'required',
            'gender'=>'required',
            'email'=>'required|email',
            'mobile'=>'required',
            'telephone'=>'nullable'
        ]);

        $teacher = Teacher::create($request->all());
        return redirect()->route('teacher.index')
                        ->with('success','New Teacher Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $teacher = Teacher::find($id);
        return view('teacher.show',compact('teacher'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $teacher = Teacher::find($id);
        return view('teacher.edit',compact('teacher'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'firstname'=>'required',
            'middlename'=>'required',
            'lastname'=>'required',
            'gender'=>'required',
            'email'=>'required|email',
            'mobile'=>'required',
            'telephone'=>'nullable'
        ]);

        $teacher = Teacher::find($id);
        $teacher->firstname = $request->get('firstname');
        $teacher->middlename = $request->get('middlename');
        $teacher->lastname = $request->get('lastname');
        $teacher->email = $request->get('email');
        $teacher->mobile = $request->get('mobile');
        $teacher->telephone = $request->get('telephone');
        $teacher->save();

        return redirect()->route('teacher.index')
                        ->with('success','Teacher updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $teacher = Teacher::find($id);
        $teacher->delete();
        return redirect()->route('teacher.index')
                        ->with('success','Teacher deleted Successfully');
    }
}
