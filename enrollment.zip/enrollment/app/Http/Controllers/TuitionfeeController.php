<?php

namespace App\Http\Controllers;

use App\Course;
use App\Tuitionfee;
use Illuminate\Http\Request;

class TuitionfeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tuitionfees = Tuitionfee::get();

        return view('tuitionfees.index',compact('tuitionfees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $courses = Course::get();
        return view('tuitionfees.create',compact('courses'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $data = $request->validate([
            'course'=>'required|unique:tuitionfees,course_id',
            'enrollment_fee'=>'required',
            'tuition_fee'=>'required',
            'laboratory_fee'=>'required',
            'registration'=>'required',
            'assessment_fee'=>'required'
            
        ]);

        $tuitionfee = Tuitionfee::create([

            'course_id'=>$data['course'],
            'enrollment_fee'=>$data['enrollment_fee'],
            'tuition_fee'=>$data['tuition_fee'],
            'laboratory_fee'=>$data['laboratory_fee'],
            'registration'=>$data['registration'],
            'assessment_fee'=>$data['assessment_fee'],

            
        ]);

        return redirect()->route('tuitionfees.index')
                        ->with('success','New School Fee created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Tuitionfee  $tuitionfee
     * @return \Illuminate\Http\Response
     */
    public function show(Tuitionfee $tuitionfee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Tuitionfee  $tuitionfee
     * @return \Illuminate\Http\Response
     */
    public function edit(Tuitionfee $tuitionfee)
    {

        $courses = Course::get();
        return view('tuitionfees.edit',compact('courses','tuitionfee'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Tuitionfee  $tuitionfee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tuitionfee $tuitionfee)
    {
         $data = $request->validate([
            'course'=>'required',
            'enrollment_fee'=>'required',
            'tuition_fee'=>'required',
            'laboratory_fee'=>'required',
            'registration'=>'required',
            'assessment_fee'=>'required',
            'total'=>'nullable'
        ]);
         $tuitionfee->update([
            'course_id'=>$data['course'],
            'enrollment_fee'=>$data['enrollment_fee'],
            'tuition_fee'=>$data['tuition_fee'],
            'laboratory_fee'=>$data['registration'],
            'registration'=>$data['registration'],
            'assessment_fee'=>$data['assessment_fee'],

        ]);
         return redirect()->route('tuitionfees.index')
                        ->with('success','School fees updated successfully');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Tuitionfee  $tuitionfee
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tuitionfee $tuitionfee)
    {
        $tuitionfee->delete();

        return redirect()->route('tuitionfees.index')
                        ->with('success','Deleted successfully');
    }
}
