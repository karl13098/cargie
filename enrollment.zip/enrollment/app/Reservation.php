<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    protected $guarded = [];

     public function student(){

    	return $this->belongsTo(Student::class);
    }

    public function course(){

    	return $this->belongsTo(Course::class);
    }

    public function scholarship(){

    	return $this->belongsTo(Scholarship::class);
    }
    public function school_year(){

        return $this->belongsTo(School_Year::class);
    }
    public function enrollment(){

        return $this->belongsTo(Enrollment::class);
    }
    public function schedule(){
        return $this->belongsTo(Schedule::class);
    }
}
