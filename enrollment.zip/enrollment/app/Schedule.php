<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    protected $guarded = [];

    protected $casts = [

        'days'=>'array',
        'day'=>'array'
    ];

   public function student(){

    	return $this->belongsTo(Student::class);
    }

    public function course(){

    	return $this->belongsTo(Course::class);
    }
    
    public function school_year(){

        return $this->belongsTo(School_Year::class);
    }

    public function section(){

    	return $this->belongsTo(Section::class);

    }

    

    public function room(){

        return $this->belongsTo(Room::class);
    }

}
