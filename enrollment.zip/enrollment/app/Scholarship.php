<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Scholarship extends Model
{
    protected $fillable = ['name','description'];


    protected $dates = ['create_at','update_at'];

    

}


