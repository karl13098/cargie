<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class School_Year extends Model
{
   protected $table = 'school_years';

   protected $guarded = [];

}
