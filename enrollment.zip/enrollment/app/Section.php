<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Section extends Model
{
    protected $guarded = [];
    protected $dates = ['created_at','update_at']; 

    public function teacher(){


    	return $this->belongsTo(Teacher::class);
    }

    public function schoolyear(){

    	return $this->belongsTo(SchoolYear::class);
    }
    public function course(){

    	return $this->belongsTo(Course::class);
    }

    
}
