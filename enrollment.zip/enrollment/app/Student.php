<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
   /*protected $fillable = ['firstname','lastname','middlename','gender','birthdate','nationality','birthplaceregion','birthplaceprovince','birthplacecity','civilstatus','employment','street','barangay','district','region','province','city','email','mobile','telephone','parentguardianname','mailingaddress','education','course_id'];*/
	protected $guarded = [];
    protected $dates = ['created_at','update_at']; 
    public function student(){

    	return $this->belongsTo(Student::class);
    }

    public function course(){

    	return $this->belongsTo(Course::class);
    }

    public function scholarship(){

        return $this->belongsTo(Scholarship::class);
    }

    public function schedule(){

        return $this->belongsTo(Schedule::class);
    }

    public function studentschedule(){

        return $this->belongsTo(Studentschedule::class);
    }

    public function enrollments(){

        return $this->hasMany(Enrollment::class);
    }

     public function getFullnameAttribute(){

    	return "{$this->firstname} {$this->middlename} {$this->lastname}";

    }

    public function getFulladdressAttribute(){

    	return"{$this->barangay} {$this->city} {$this->province}";
    }


    public function getFullbirthplaceAttribute(){
    	return "{$this->street} {$this->barangay} {$this->city} {$this->province}";
    }



}
