<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Studentrequirement extends Model
{
    protected $guarded = [];

    protected $casts = [

    	'name'=>'array',
    ];

    public function student(){

    	return $this->belongsTo(Student::class);
    }

    public function enrollment(){

    	return $this->belongsTo(Enrollment::class);

    }
    	
    
}
