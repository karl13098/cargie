<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Studentschedule extends Model
{
    protected $guarded = [];

    public function student(){

    	return $this->belongsTo(Student::class);

    }

    public function schedule(){

    	return $this->belongsTo(Schedule::class);
    }

    public function enrollment(){

    	return $this->belongsTo(Enrollment::class);
    }

    public function course(){

        return $this->belongsTo(Course::class);
    }
}
