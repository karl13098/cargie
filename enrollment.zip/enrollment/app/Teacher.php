<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    protected $fillable =['firstname','middlename','lastname','gender','email','mobile','telephone'];
    protected $dates =['created_at','update_at'];

    public function getFullnameAttribute(){

    	return "{$this->firstname} {$this->middlename} {$this->lastname}";
    }
}
