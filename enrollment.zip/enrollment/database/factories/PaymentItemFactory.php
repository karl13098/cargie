<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Payment_item;
use Faker\Generator as Faker;

$factory->define(Payment_item::class, function (Faker $faker) {
    return [
        //
    ];
});
