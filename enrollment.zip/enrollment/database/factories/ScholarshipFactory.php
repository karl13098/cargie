<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Scholarship;
use Faker\Generator as Faker;

$factory->define(Scholarship::class, function (Faker $faker) {
    return [
        //
    ];
});
