<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SchoolYear;
use Faker\Generator as Faker;

$factory->define(SchoolYear::class, function (Faker $faker) {
    return [
        //
    ];
});
