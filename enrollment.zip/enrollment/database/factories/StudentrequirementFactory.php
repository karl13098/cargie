<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Studentrequirement;
use Faker\Generator as Faker;

$factory->define(Studentrequirement::class, function (Faker $faker) {
    return [
        //
    ];
});
