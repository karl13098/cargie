<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tuitionfee;
use Faker\Generator as Faker;

$factory->define(Tuitionfee::class, function (Faker $faker) {
    return [
        //
    ];
});
