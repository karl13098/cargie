<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSchedulesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('schedules', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('course_id');
            $table->integer('section_id');
            $table->integer('room_id');
            $table->string('start_time_AM')->nullable();
            $table->string('end_time_AM')->nullable();
            $table->string('start_time_PM')->nullable();
            $table->string('end_time_PM')->nullable();
            $table->string('days');
             $table->string('start_time_AMA')->nullable();
            $table->string('end_time_AMA')->nullable();
            $table->string('start_time_PMA')->nullable();
            $table->string('end_time_PMA')->nullable();
            $table->string('day');
            
            $table->integer('school_year_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('schedules');
    }
}
