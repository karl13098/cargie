<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('firstname');
            $table->string('lastname');
            $table->string('middlename');
            $table->string('gender');
            $table->string('birthdate');
            $table->string('nationality');
            $table->string('birthplaceregion');
            $table->string('birthplaceprovince');
            $table->string('birthplacecity');
            $table->string('civilstatus');
            $table->string('employment');
            $table->string('street');
            $table->string('barangay');
            $table->string('district');
            $table->string('region');
            $table->string('province');
            $table->string('city');
            $table->string('email');
            $table->integer('mobile');
            $table->integer('telephone');
            $table->string('parentguardianname');
            $table->string('mailingaddress');
            $table->string('education');
            $table->integer('course_id');
            $table->integer('scholarship_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}
