<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTuitionfeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tuitionfees', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('course_id')->unique();
            $table->decimal('enrollment_fee',10,2);
            $table->decimal('tuition_fee',10,2);
            $table->decimal('laboratory_fee',10,2);
            $table->decimal('registration',10,2);
            $table->decimal('assessment_fee',10,2);
            $table->text('description')->nullable();
            $table->decimal('total',10,2)->nullable();
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tuitionfees');
    }
}
