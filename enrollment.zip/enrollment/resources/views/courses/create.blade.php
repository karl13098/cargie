@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        
        <div class="row">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('courses.store') }}">
		
		@csrf
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="name" size="35" required><sup class="text-danger">*</sup></td>
		</tr>

		<tr>
			<td><label>Type</label></td>
			<td><input type="text" name="types" size="35" required><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description" size="50"></td>
		</tr>
		
		<tr>
			
		
			<td><a href="{{route('courses.index')}}" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Create</button>

	
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

@endsection

