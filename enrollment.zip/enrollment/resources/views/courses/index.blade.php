@extends('layout')
@section('content')



    <div class="content-wrapper">

         @if($message = Session::get('success'))
            <div class="alert alert-success">
                {{ $message }}
            </div>
        @endif
       
    
        
        <div class="card">
            <div class="card-body">
                <h2 class="card-title" >Data table <a class="btn btn-success" href="{{route('courses.create')}}" style="margin-left: 800px">Create New</a></h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                
                                <th>Name</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th>Action</th>
                                
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($courses as $course)
                            <tr>
                                
                                <td>{{$course->name}}</td>
                                <td>{{$course->types}}</td>
                                <td>{{$course->description}}</td>


                                <td>
                                    <form action="{{route('courses.destroy',$course->id)}}" method="post">
                                                
                                    <a class="btn btn-sm btn-secondary" href="{{route('courses.edit',$course->id)}}">EDIT</a>
                                    @csrf
                                    @method('DELETE')
                                     <button  class="btn btn-outline-danger" onclick=" return confirm('Are you sure?')" 
                     >DELETE</button>
                               
                               
                            </form>
                                </td>
                            </tr>
                                @endforeach


                            </tbody>
                        </table>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

  @endsection