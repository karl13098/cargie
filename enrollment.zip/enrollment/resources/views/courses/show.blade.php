@extends('layout')

@section('content')
	  <div class="content-wrapper">
        <h1 class="page-title">Information</h1>
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">
				<tr>
					<td><strong>Course:</strong></td>
					<td>{{$courses->name}}</td>
				</tr>
	
				
	
	
	
				
			
			<tr>
			<td><a href="{{route('courses.index')}}" class="btn btn-sm btn-success">back</a></td>
		</tr>

</table>
</div>
</div>
</div>
</div>
</div>

@endsection