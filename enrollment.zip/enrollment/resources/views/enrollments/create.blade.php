@extends('layout')
@section('content')
	


	<div class="content-wrapper">
        <h1 class="page-title">Enrollment Form 
        	<select class="flex-column" name="reservation_id" style="margin-left: 500px">
					<option style="" value="">--Select--</option>
					@foreach($reservations as $reservation)
						<option value="{{ $reservation->id }}" >{{ $reservation->fullname }}</option>
					@endforeach
				</select>



        </h1> 	
				
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('enrollments.store') }}">
		
		@csrf
	<div class='form-group'>
	 <table id="order-listing" class="table tab-content" >
	
		
		
		
			

		<tr>
			<td>EnrollmentID<input type="text" name="id"></td>
			<td>Section<input type="text" name=""></td>

		</tr>

		<tr>
			<td>Name<input style="margin-left: 45px" type="text" name="" id="reservation_id" readonly></td>
			<td>Academic Year<input type="text" name="" style="margin-left: 2px"></td>
		</tr>

		<tr>
			<td>Course<input type="text" name="course" style="margin-left: 38px"></td>
			<td>Scholarship<input type="text55555" name=""></td>
		</tr>



	</table>
</div>

</form>
			</div>
			</div>
		</p>
		</div>
</div>
</div>

@endsection

