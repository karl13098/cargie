@extends('layout')
@section('content')



    <div class="content-wrapper">
        <!-- <h1 class="pull-right">
           <a class="btn btn-primary pull-right" href="" style="margin-top: -10px;margin-bottom: 5px">Enroll Student</a>
        </h1>-->
        <h1 class="page-title">Pending Enrollee</h1>
        
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                
                                <th>Course</th>
                                
                                
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($enrollments as $enrollment)
                            <tr>
                                <td>{{$enrollment->student_id}}</td>
                                <td>{{$enrollment->student->name}}</td>
                                
                                <td>{{$enrollment->course->name}}</td>
                                
                                


                                <td>
                                    <form action="{{route('enrollments.destroy',$enrollment->id)}}" method="post">
                                    <a class="btn btn-sm btn-primary" href="{{route('enrollments.show',$enrollment->id)}}">View</a>
                                    <a class="btn btn-sm btn-secondary" href="{{route('enrollments.edit',$enrollment->id)}}">Edit</a>
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure you?')">Delete</button>
                            </form>
                                </td>
                            </tr>
                                @endforeach


                            </tbody>
                        </table>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

  @endsection