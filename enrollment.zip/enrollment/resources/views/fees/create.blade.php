@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        <h1 class="page-title">Scholarship</h1>
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('fees.store') }}">
		
		@csrf
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr><td><label>Name:</label></td>
			<td><input type="text" name="name" required><sup class="text-danger">*</sup>
				

			</td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description" size="50"></td>
		</tr>

		<tr>
			<td><label>Fee</label></td>
			<td><input type="number" name="fee" min="0" step="0.01" required><sup class="text-danger">*</sup></td>

		</tr>

		<tr>
			<td><a href="{{route('fees.index')}}" class="btn btn-sm btn-success">Back																	</a>
			</td>
			<td>
				<button type="submit" class="btn btn-sm btn-primary">Create</button>
			</td>
	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

@endsection

