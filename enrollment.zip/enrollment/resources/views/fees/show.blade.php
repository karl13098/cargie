@extends('layout')

@section('content')
	  <div class="content-wrapper">
        
        <div class="row">
            <div class="card-body">
                
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">
				<tr>
					<td><strong>Name:</strong></td>
					<td>{{$scholarship->name}}</td>
				</tr>
	
				
	
				<tr>
					<td><strong>Description:</strong></td>
					<td> {{$scholarship->description}}</td>
				</tr>
	
				
	
				

			
				
			
			<tr>
			<td><a href="{{route('scholarships.index')}}" class="btn btn-sm btn-success">back</a></td>
		
		</tr>

</table>
</div>
</div>
</div>
</div>
</div>

@endsection