@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        <h1 class="page-title">Scholarship</h1>
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('scholarships.store') }}">
		
		@csrf
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Types of Scholarship</h2>
		<tr><td><label>Name:</label></td>
			<td><input type="text" name="name" required><sup class="text-danger">*</sup>
				

			</td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description" size="50"></td>
		</tr>
		<tr><td><div class="form-group">
			<td><a href="{{route('scholarships.index')}}" class="btn btn-sm btn-success">Back</a>
			</td><td><td><button type="submit" class="btn btn-sm btn-primary">Create</button>

		</td></div>
	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

@endsection

