@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        
        <div class="row">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('reservations.update',$reservation->id) }}">
		
		@csrf
		@method('PUT')
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="fullname" size="35" value="{{$reservation->student->fullname}}" readonly></td>
		</tr>
		<tr>
			<td><label>Email</label></td>
			<td><input type="email" name="email" size="35" value="{{$reservation->student->email}}" readonly></td>
		</tr>

		<tr><td><label>Course</label></td>
			<td><select class="form-control" name="course" style="width: 290px">
					
					@foreach($courses as $course)
					@if($course->id == $reservation->course_id)

						<option selected value="{{ $course->id }}">{{ $course->name }}</option>
					@else
						<option value="{{ $course->id }}">{{ $course->name }}</option>
					@endif
					
					@endforeach
				</select>

			</td>
		</tr>



		<tr><td><label>Course</label></td>
			<td><select class="form-control" name="scholarship" style="width: 290px">
					
					@foreach($scholarships as $scholarship)
					@if($scholarship->id == $reservation->scholarship_id)

						<option selected value="{{ $scholarship->id }}">{{ $scholarship->name }}</option>
					@else
						<option value="{{ $scholarship->id }}">{{ $scholarship->name }}</option>
					@endif
					
					@endforeach
				</select>

			</td>
		</tr>
		<tr>
			<td><label>Address</label></td>
			<td><input type="text" name="fulladdress" size="35" value="{{$reservation->student->fulladdress}}" readonly></td>
		</tr>
			
		<div class="form-group">
			<td><a href="{{route('reservations.index')}}" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

@endsection

