@extends('layout')
@section('content')



    <div class="content-wrapper dataTables_wrapper container-fluid dt-bootstrap4la" >
       


        <!-- <h1 class="pull-right">
           <a class="btn btn-primary pull-right" href="" style="margin-top: -10px;margin-bottom: 5px">Enroll Student</a>
        </h1>-->
          @if($message = Session::get('success'))
            <div class="alert alert-success">
                {{ $message }}
            </div>
        @endif
        @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
        
        
        <div class="card" >
            <div class="card-body">
                <h2 class="card-title">Reservation <a class="btn btn-success" href="{{route('students.create')}}" style="margin-left: 800px">Create New</a></h2>
               
               
                
                <div class="row">
                    <div class="col-12" >

                        <table id="order-listing"  class="table table-striped" style="width:100%;" data-page-length='25' >
                            <thead>
                            <tr>
                                
                                <th>Name</th>
                                <th>Email</th>
                                <th>Course</th>
                                <th>Scholarship</th>
                               
                                
                               
                                <th>Actions</th>
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($reservations as $reservation)
                            <tr>
                               
                                <td>{{$reservation->student->fullname}}</td>
                                <td>{{$reservation->student->email}}</td>
                                <td>{{$reservation->course->name}}</td>
                                <td>{{$reservation->scholarship->name}}</td>
                                
                               


                                <td>  
                                     <form  action="{{route('reservations.destroy',$reservation->id)}}" method="POST">
                                    
                                    <a class="btn btn-sm btn-primary" href="{{route('reservations.show',$reservation->id)}}">VIEW</a>
                                    <a class="btn btn-sm btn-secondary" href="{{route('reservations.edit',$reservation->id)}}">EDIT</a>
                                    @csrf
                                    @method('DELETE')
                              
                                    
                <button  class="btn btn-outline-danger" onclick=" return confirm('Are you sure?')" 
                     >DELETE</button>
                </form>
           
                                </td>
                            </tr>
                                @endforeach


                            </tbody>
                            <tfoot><script>
 
</script>
</tfoot>
                        </table>


                        

                    </div>
                </div>
            </div>
        </div>
    </div>


  @endsection