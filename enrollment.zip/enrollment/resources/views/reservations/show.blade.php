@extends('layout')

@section('content')
	  <div class="content-wrapper">
        
        <div class="row">
            <div class="card-body">
                <h2 class="card-title">Information</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">

	
				
				<tr>
					<td><strong>Name:</strong></td>
					<td> {{$reservation->student->fullname}}</td>
				</tr>
	
				
	
				<tr>
					<td><strong>Email:</strong></td>
					<td>{{$reservation->student->email}}</td>
				</tr>

				<tr>
					<td><strong>Course:</strong></td>
					<td>{{$reservation->course->name}}</td>
				</tr>
				<tr>
					<td><strong>Scholarship:</strong></td>
					<td>{{$reservation->scholarship->name}}</td>
				</tr>
				<tr>
					<td><strong>Address:</strong></td>
					<td> {{$reservation->student->fulladdress}}</td>
				</tr>
				<tr>
					
					<td><strong>MobileNo:</strong></td>
					<td>{{$reservation->student->mobile}}</td>
				
				</tr>
				<tr>
					<td><strong>TelephoneNo:</strong></td>
					<td>{{$reservation->student->telephone}}</td>
				</tr>

			
			
				
			
			<tr>
			<td><a href="{{route('reservations.index')}}" class="btn btn-sm btn-success">Back</a></td>
			<td>
				<button class="btn btn-primary"
					data-target="#registration-form" data-toggle="modal">Enroll</button>
			</td>
			
		</tr>

</table>
<div class="modal" tabindex="-1" role="dialog" id="registration-form">
  <div class="modal-dialog" role="document">
  	<form method="Post" action="{{route('enrollments.store')}}">

	<input type="hidden" name="student" value="{{$reservation->student_id}}">
	<input type="hidden" name="course" value="{{$reservation->course_id}}">
	<input type="hidden" name="scholarship" value="{{$reservation->scholarship_id}}">
	
	@csrf
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="form-group">
      		<label for="school_year">School Year</label>
      		<select name="school_year" id="school_year" class="form-control">
      	
					@foreach($school_years as $school_year)
						<option value="{{$school_year->id }}">{{ $school_year->year }}</option>
					@endforeach
				</select><sup class="text-danger">*</sup>

      	</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button class="btn btn-primary">Submit</button>
      </div>
    </div>

	</form>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>

@endsection