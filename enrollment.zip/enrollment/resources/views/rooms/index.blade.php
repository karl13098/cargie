@extends('layout')
@section('content')



    <div class="content-wrapper">
        <!-- <h1 class="pull-right">
           <a class="btn btn-primary pull-right" href="" style="margin-top: -10px;margin-bottom: 5px">Enroll Student</a>
        </h1>-->

        @if($message = Session::get('success'))
            <div class="alert alert-success">
                {{ $message }}
            </div>
        @endif
    
        
        <div class="row">
            <div class="card-body">
                <h2 class="card-title">Data table  <a class="btn btn-success" href="{{route('rooms.create')}}" style="margin-left: 800px">Create New</a></h2> 
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>

                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-sm" style="width:100%;" onclick="">
                            <thead>
                            <tr>
                            
                                <th>Name</th>
                                <th>Description</th>
                                <th>Active</th>
                                <th>Actions</th>
                                
                            
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($rooms as $room)
                            <tr>
                                
                                <td>{{$room->name}}</td>
                                <td>{{$room->description}}</td>
                                <td>{{$room->is_active ? 'Yes': 'No'}}</td>
                                
                               


                                <td>
                                    <form action="{{route('rooms.destroy',$room->id)}}" method="POST"> 
                                    <a class="btn btn-sm btn-secondary" href="{{route('rooms.edit',$room->id)}}">EDIT</a>

                                    
                                   @csrf
                                   @method('DELETE')
                                    <button  class="btn btn-outline-danger" onclick=" return confirm('Are you sure?')" 
                     >DELETE</button>
                            </form>
                                </td>
                            </tr>
                                @endforeach


                            </tbody>
                        </table>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(document).ready(function() {
    var table = $('#order-listing').DataTable();
     
    $('#order-listing tbody').on('click', 'tr', function () {
        var data = table.row( this ).data();
        alert( 'You clicked on '+data[0]+'\'s row' );
    } );
} );
</script>

  @endsection