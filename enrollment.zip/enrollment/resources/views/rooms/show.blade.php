@extends('layout')

@section('content')
	  <div class="content-wrapper">
        <h1 class="page-title">Information</h1>
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">
				<tr>
					<td><strong>ID:</strong></td>
					<td>{{$reservation->id}}</td>
				</tr>
	
				
	
				<tr>
					<td><strong>Name:</strong></td>
					<td> {{$reservation->student->fullname}}</td>
				</tr>
	
				
	
				<tr>
					<td><strong>Description:</strong></td>
					<td>{{$reservation->student->email}}</td>
				</tr>

				<tr>
					<td><strong>Teacher:</strong></td>
					<td>{{$reservation->course->name}}</td>
				</tr>
				<tr>
					<td><strong>Address:</strong></td>
					<td> {{$reservation->student->fulladdress}}</td>
				</tr>
				<tr>
					
					<td><strong>Mobile No:</strong></td>
					<td>{{$reservation->student->mobile}}</td>
				
				</tr>
		

			
				
			
			<tr>
			<td><a href="{{route('reservation.index')}}" class="btn btn-sm btn-success">back</a></td>
		<td>	<form action="{{ route('enrollment.store') }}" method="POST">
				<input type="hidden" name="user_id" value="{{ $reservation->student->id }}">
				@csrf
				<button class="btn btn-primary">Enroll</button>
			</form></td>
		</tr>

</table>
</div>
</div>
</div>
</div>
</div>

@endsection