@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        
        <div class="column">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                     @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('schedules.update',$schedule->id) }}">
		
		@csrf
		@method('PUT')
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	
		<tr>
			<td><label>School Year</label></td>
      		<td><select name="school_year" class="form-control" style="width: 100px">
      	
					@foreach($school_years as $school_year)
						<option value="{{$school_year->id }}">{{ $school_year->year }}</option>
					@endforeach
				</select></td>
		</tr>
		<tr>

			
				
				<td><label>Course</label></td>
			<td><select class="form-control" name="course" style="width: 490px" >
					
					@foreach($courses as $course)
					@if($course->id == $schedule->course->id)

						<option selected value="{{ $schedule->course->id }}">{{ $schedule->course->name }} {{$schedule->course->types}}</option>
					@else
						
					@endif
					
					@endforeach
				</select>

			</td>
		</tr>

		<tr>
			<td><label>Section</label></td>

			<td>
				
				<select class="form-control" name="section" style="width: 490px">
					
					@foreach($sections as $section)
					@if($section->id == $schedule->section->id)
						<option selected value="{{$schedule->section->id }}">{{ $schedule->section->name }} {{ $schedule->section->description }}</option>
					@else 
					@endif
						
					@endforeach
				</select>
			</td>
		</tr>

	
		<tr>
			<td><label>Room</label></td>

			<td>
				
				<select class="form-control" name="room" style="width: 400px">
					<option selected value="{{$schedule->room_id}}">{{ $schedule->room->name }} {{ $schedule->room->description }}</option>
					@foreach($rooms as $room)
						<option value="{{$room->id }}">{{ $room->name }} {{ $room->description }}</option>
					@endforeach
				</select>
			</td>
		</tr>


		<tr>
			<td><label>Days</label></td>
			<td><input type="checkbox" value="M" name="days[]">M  
				<input type="checkbox" value="T" name="days[]" style="margin-left: 20px">T
				<input type="checkbox" value="W" name="days[]" style="margin-left: 20px">W
				<input type="checkbox" value="Th" name="days[]" style="margin-left: 20px">Th
				<input type="checkbox" value="F" name="days[]" style="margin-left: 20px">F
			</td>
			<td><input type="checkbox" value="M" name="day[]">M  
				<input type="checkbox" value="T" name="day[]" style="margin-left: 20px">T
				<input type="checkbox" value="W" name="day[]" style="margin-left: 20px">W
				<input type="checkbox" value="Th" name="day[]" style="margin-left: 20px">Th
				<input type="checkbox" value="F" name="day[]" style="margin-left: 20px">F
			</td>
		</tr>

		<tr>
			<td><label>Time(From-To)</label></td>
			<td><input type="time"  name="start_time_AM"
       min="06:00" max="18:00" required>
			
				<input type="time" name="end_time_AM"
       min="06:00" max="18:00" required>
			</td>

			<td><input type="time"  name="start_time_AMA"
       min="06:00" max="18:00" >
			
				<input type="time" name="end_time_AMA"
       min="06:00" max="18:00" >
			</td>

			
		</tr>
		<tr>
			<td><label>Time(From-To)</label></td>
			<td><input type="time" name="start_time_PM"
       >
			
				<input type="time" id="appt" name="end_time_PM"
        >
			</td>
			<td><input type="time" name="start_time_PMA"
        >
			
				<input type="time" id="appt" name="end_time_PMA"
        >
			</td>

			
		</tr>
		
		<tr>
			
		<div class="form-group">
			<td><a href="{{route('schedules.index')}}" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

@endsection

