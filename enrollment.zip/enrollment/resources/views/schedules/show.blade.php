@extends('layout')

@section('content')
	  <div class="content-wrapper">
        
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table class="table table-bordered" style="width: 600px" >


	
				
				<tr>
					<td><strong>Course:</strong></td>
					<td>{{$schedule->course->name}}</td>
					<td>
				</tr>
				<tr>
					<td><strong>Days:</strong></td>
					<td>
                   		 @foreach($schedule->days as $dayss)
                         <span >{{ $dayss }}</span>
                         @endforeach
                   </td>
                   <td >
                  		@foreach($schedule->day as $da)
                         <span >{{ $da }}</span>
                         @endforeach
                   </td>
				</tr>
	
				
	
				<tr>
					<td><strong>Time:</strong></td>
					<td>{{$schedule->start_time_AM}}  {{$schedule->end_time_AM}} <br>
                                    {{$schedule->start_time_PM}}  {{$schedule->end_time_PM}}

                    </td>
                    <td>{{$schedule->start_time_AMA}}  {{$schedule->end_time_AMA}} <br>
                                    {{$schedule->start_time_PMA}}  {{$schedule->end_time_PMA}}

                   </td>
				</tr>

				
				
				
				<tr>
					
					<td><strong>Section:</strong></td>
					<td>{{$schedule->section->name}} {{$schedule->section->description}}</td>
					<td></td>
				
				</tr>
				<tr>
					<td><strong>Teacher:</strong></td>
					<td>{{$schedule->section->teacher->fullname}}</td>
					<td></td>
				</tr>

				<tr>
					<td><strong>Room:</strong></td>
					<td>{{$schedule->room->name}} {{$schedule->room->description}}</td
						>
					<td></td>
				</tr>

			
			
				
			
			<tr>
			<td><a href="{{route('schedules.index')}}" class="btn btn-sm btn-success">Back</a></td>
			
			
		</tr>

</table>

</div>
</div>
</div>
</div>
</div>

@endsection