@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        
        <div class="row">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('school_years.update',$school_year->id) }}">
		
		@csrf
		@method('PUT')
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr><td><label>School year:</label></td>
			<td><input type="text" name="year" required value="{{$school_year->year}}"><sup class="text-danger">*</sup>
				

			</td>
		</tr>
		<tr>
			<td><label>Default</label></td>
			<td><select name="default">
				
				<option value="1">Yes</option>
				<option value="0">No</option>
			</select></td>

		</tr>
		<tr><td><div class="form-group">
			<td><a href="{{route('school_years.index')}}" class="btn btn-sm btn-success">Back</a>
			</td><td><td><button type="submit" class="btn btn-sm btn-primary">Save</button>

		</td></div>
	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

@endsection

