@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        
        <div class="card">
                   
              
            <div class="card-body">
               
             
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('sections.store') }}">
		
		@csrf
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="name" size="35" required><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description"  size="50"></td>
		</tr>

		<tr>
			<td><label>Teacher</label></td>

			<td>
				
				<select class="form-control" name="teacher" style="width: 300px">
					<option value="">--Select--</option>
					@foreach($teachers as $teacher)
						<option value="{{$teacher->id }}">{{ $teacher->fullname }}</option>
					@endforeach
				</select><sup class="text-danger">*</sup>

			</td>
		</tr>
		
		<tr>
			
		<div class="form-group">
			<td><a href="{{route('sections.index')}}" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Create</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

@endsection

