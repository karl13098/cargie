@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        
        <div class="row">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                     @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

                  
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('sections.update',$section->id) }}">
		
		@csrf
		@method('PUT')
		
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="name" size="35" required value="{{$section->name}}"><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description"  size="50" value="{{$section->description}}"></td>
		</tr>

		<tr><td><label>Teacher</label></td>
			<td><select class="form-control" name="teacher" style="width: 300px">
					
					@foreach($teachers as $teacher)
					@if($teacher->id == $section->teacher_id)

						<option selected value="{{ $section->teacher->id }}">{{ $section->teacher->fullname }}</option>
					@else
						<option value="{{$teacher->id}}">{{ $teacher->fullname }}</option>
						
					@endif
					
					@endforeach
				</select>

			</td>
		</tr>
			
		<div class="form-group">
			<td><a href="{{route('sections.index')}}" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

@endsection

