@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        <h1 class="page-title">Semester</h1>
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('semester.update',$semester->id) }}">
		
		@csrf
		@method('PUT')
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	<h2></h2>
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="name" size="35" value="{{$semester->name}}"></td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description" value="{{$semester->description}}"></td>
		</tr>
		<tr>
			<td><label>Number</label></td>
			<td><input type="text" name="number" value="{{$semester->number}}"></td>
		</tr>
		
		
		<tr>
			
		<div class="form-group">
			<td><a href="{{route('semester.index')}}" class="btn btn-sm btn-success">Back</a></td>
			<td><button type="submit" class="btn btn-sm btn-primary">Save</button></td>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

@endsection

