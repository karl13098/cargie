@extends('layout')
@section('content')



    <div class="content-wrapper">
         <h1 class="pull-right">
           <a class="btn btn-primary pull-right" style="margin-top: -10px;margin-bottom: 5px" href="{{route('semester.create')}}">Add New</a>
        </h1>
        <h1 class="page-title">Semester</h1>
        
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Number</th>
                                
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($semester as $semesters)
                            <tr>
                                
                                <td>{{$semesters->id}}</td>
                                <td>{{$semesters->name}}</td>
                                <td>{{$semesters->description}}</td>
                                <td>{{$semesters->number}}</td>
                                


                                <td>
                                    <form action="{{route('semester.destroy',$semesters->id)}}" method="post">
                                    <a class="btn btn-sm btn-primary" href="{{route('semester.show',$semesters->id)}}">View</a>
                                    <a class="btn btn-sm btn-secondary" href="{{route('semester.edit',$semesters->id)}}">Edit</a>
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure you?')">Delete</button>
                            </form>
                                </td>
                            </tr>
                                @endforeach


                            </tbody>
                        </table>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

  @endsection