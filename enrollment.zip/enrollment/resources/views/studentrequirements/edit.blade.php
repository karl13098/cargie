@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('studentrequirements.store',$studentrequirement->id) }}">
		
		@csrf
		@method('put')
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr>
			<td><label>Name:</label></td>
			<td><select name="student" class="form-control" style="width: 400px">
      	
					@foreach($students as $student)
					@if($studentrequirement->student->id == $student->id)
						<option selected value="{{$student->id }}">{{ $student->fullname }}</option>
					@else
					<option selected value="{{$student->id }}">{{ $student->fullname }}</option>
					@endif
					@endforeach
				</select></td></td>
		</tr>
		<tr>
			<td><label>Requirements</label></td>
			<td><input type="checkbox" name="name[]" Selected value="Birth Certificate/NSO" size="50">Birth Certificate/NSO</td>
			<td><input type="checkbox" name="name[]" Selected value="School Credential" size="50">School Credential</td>
			<td><input type="checkbox" name="name[]" Selected value="Brgy.Clearance" size="50">Brgy. Clearance</td>
		</tr>
		<tr><td><div class="form-group">
			<td><a href="{{route('studentrequirements.index')}}" class="btn btn-sm btn-success">Back</a>
			</td><td><button type="submit" class="btn btn-sm btn-primary">Save</button>

		</td></div>
	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

@endsection

