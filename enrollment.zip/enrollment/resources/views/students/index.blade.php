@extends('layout')
@section('content')



    
    <div class="content-wrapper">  
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                <th>ControlNo:</th>         
                                <th>Name</th>  
                                <th>Course</th>  
                                <th>Scholarship</th> 
                                <th>Actions</th>         
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($students as $student)
                            <tr>            
                                <td>{{$student->id}}</td>    
                                <td>{{$student->fullname}}</td>
                                <td>
                                    @foreach($student->enrollments as $enrollment)
                                        <span >{{ $enrollment->course->name }}</span>
                                    @endforeach
                                </td>
                                <td>
                                    @foreach($student->enrollments as $enrollment)
                                        <span>{{$enrollment->scholarship->name}}</span>
                                    @endforeach
                                </td>
                                <td>
                                   
                                    <a class="btn btn-sm btn-outline-info" href="{{route('students.show',$student->id)}}">Records</a>
                                    
                                    <a class="btn btn-sm btn-secondary" href="{{route('students.edit',$student->id)}}">EDIT</a>
                                    
                                    <button class="btn btn-outline-success"
                                      data-target="#registration-form" data-toggle="modal">Add Schedule
                                    </button>        
                                    </td>
                                </form>
                                    </tr>
                                    @endforeach
                            </tbody>
                        </table>

<div class="modal" tabindex="-1" role="dialog" id="registration-form">
  <div class="modal-dialog" role="document">
    <form method="Post" action="{{route('studentschedules.store')}}">
    <input type="hidden" name="student" value="{{$student->id}}">   
   
    
    @csrf
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Schedule</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <label for="schedule">Section</label>
            <select name="schedule" id="schedule" class="form-control">
        
                    @foreach($schedules as $schedule)
                    @if($schedule->course_id == $enrollment->course_id)
                        <option value="{{$schedule->id }}">{{ $schedule->section->name }} {{$schedule->section->description}}</option>
                    @else
                    
                    
                        
                    @endif
                    @endforeach
                </select><sup class="text-danger">*</sup>

        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button class="btn btn-primary">Submit</button>
      </div>
    </div>

    </form>
  </div>
</div>



                        

                        

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

  @endsection