@extends('layout')

@section('content')
	  <div class="content-wrapper">
        
        <div class="row">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">

	
				
	
				<tr>
					<td><strong>Name:</strong></td>
					<td> {{$student->fullname}}</td>
				</tr>
	
				
	
				<tr>
					<td><strong>Email:</strong></td>
					<td>{{$student->email}}</td>
				</tr>

				<tr>
					<td><strong>Address:</strong></td>
					<td> {{$student->fulladdress}}</td>
				</tr>
				<tr>
					
					<td><strong>MobileNo:</strong></td>
					<td>{{$student->mobile}}</td>
				
				</tr>
				<tr>
					<td><strong>TelephoneNo:</strong></td>
					<td>{{$student->telephone}}</td>
				</tr>

			
				
			
			<tr>
			<td><a href="{{route('students.index')}}" class="btn btn-sm btn-success">back</a></td>
			
		</tr>

</table>
</div>
</div>
</div>
</div>
</div>

@endsection