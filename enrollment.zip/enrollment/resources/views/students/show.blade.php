@extends('layout')

@section('content')
	  <div class="content-wrapper">
        
        <div class="row">
            <div class="card-body">
                <h2 class="card-title">Student Information</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">

	
				
	
				<tr>
					<td><strong>Name:</strong></td>
					<td> {{$student->fullname}}</td>
				</tr>

				<tr>
					<td><strong>Gender:</strong></td>
					<td> {{$student->gender}}</td>
				</tr>

				<tr>
					<td><strong>Employment:</strong></td>
					<td> {{$student->employment}}</td>
				</tr>




				<tr>
					<td><strong>Email:</strong></td>
					<td> {{$student->email}}</td>
				</tr>

				<tr>
					<td><strong>Address:</strong></td>
					<td> {{$student->fulladdress}}</td>
				</tr>

				<tr>
					<td><strong>Mobile No:</strong></td>
					<td> {{$student->mobile}}</td>
				</tr>


				<tr>
					<td><strong>Parent/Guardian:</strong></td>
					<td> {{$student->parentguardianname}}</td>
				</tr>

				<tr>
					<td><strong>Complete Mailing Address:</strong></td>
					<td> {{$student->mailingaddress}}</td>
				</tr>
	
				
	
				<tr>
					<td><strong>Course:</strong></td>
					<td>
                                    @foreach($student->enrollments as $enrollment)
                                        <span >{{ $enrollment->course->name }}</span>
                                    @endforeach
                                </td>
				</tr>

				<tr>
					<td><strong>Scholarship:</strong></td>
					 <td>
                                    @foreach($student->enrollments as $enrollment)
                                        <span>{{$enrollment->scholarship->name}}</span>
                                    @endforeach
                                </td>
				</tr>
				

			
				
			
			<tr>
			<td><a href="{{route('students.index')}}" class="btn btn-sm btn-success">Back</a></td>
			<td>
				
			</td>
			
				
		</tr>

</table>



</div>
</div>
</div>
</div>
</div>

@endsection