<!DOCTYPE html>
<html>

<head>
    <style>
        table{
            border-collapse: collapse;
        }

        table,th,td {
            border: 1px solid black;
        }
        input{
            background: transparent;
            border: none;
            font-weight: bold;
        }

    </style>

	
	<div >
	<h2 style="text-align: center;margin-top: 100px">CMC INSTITUTE OF BUSINESS MANAGEMENT <br>SKILLS TRAINING AND ASSESSMENT CENTER INC.</h2><h5 style="text-align: center">SEC. REG. CN201945172 <br>Business Address:J.A. Clarin Street, Poblacion III Tagbilaran City <br>Email Address:cmc.skillsinstitute@gmail.com madulara@yahoo.com</h5></div>
	
</head>
<body>
	<table  width="100%">
		
			<tr>
				<td>StudentID: <input type="text" name="" value="{{$studentschedule->student->id}}" style="margin-left: 50px"></td>	
				<td>School year:<input type="text" name="" value="{{$studentschedule->schedule->school_year->year}}"  style="margin-left: 50px"></td>			
			</tr>
			<tr>
				<td>Name:<input type="text" name="" value="{{$studentschedule->student->fullname}}"  style="margin-left: 80px"></td>
                <td>Scholarship: @foreach($studentschedule->student->enrollments as $enrollment)
                                        <span style="margin-left: 45px">{{$enrollment->scholarship->name}}</span>
                                    @endforeach</td>

			</tr>

		
		
	</table>
	<table id="order-listing" class="table table-sm" style="width:100%;border-collapse: collapse;border: 1px solid black;">
                            <thead>
                            <tr>
                                
                                <th>Course</th>
                                <th>Type</th>
                                <th>Time</th>
                                <th>Day</th>
                                <th>Section</th>
                                
                                <th>Teacher</th>
                                <th>Room</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td style="text-align: center;">{{$studentschedule->schedule->course->name}}</td>

                                <td style="text-align: center;">{{$studentschedule->schedule->course->types}}</td>
                               <td style="text-align: center;">{{$studentschedule->schedule->start_time_AM}}  {{$studentschedule->schedule->end_time_AM}} <br>
                                    {{$studentschedule->schedule->start_time_PM}}  {{$studentschedule->schedule->end_time_PM}}

                                </td>
                                <td style="text-align: center;">
                                   @foreach($studentschedule->schedule->days as $day)
                                        <span >{{ $day }}</span>
                                    @endforeach
                                </td>
                                <td style="text-align: center;">{{$studentschedule->schedule->section->name}} </td>
                                <td style="text-align: center;">{{$studentschedule->schedule->section->teacher->fullname}}</td>
                                    
                                <td style="text-align: center;">{{$studentschedule->schedule->room->name}}</td>
                            </tr>
                             <tr>
                                <td style="text-align: center;">{{$studentschedule->schedule->course->name}}</td>

                                <td style="text-align: center;">{{$studentschedule->schedule->course->types}}</td>
                               <td style="text-align: center;">{{$studentschedule->schedule->start_time_AMA}}  {{$studentschedule->schedule->end_time_AMA}} <br>
                                    {{$studentschedule->schedule->start_time_PMA}}  {{$studentschedule->schedule->end_time_PMA}}

                                </td>
                                <td style="text-align: center;">
                                   @foreach($studentschedule->schedule->day as $da)
                                        <span >{{ $da }}</span>
                                    @endforeach
                                </td>
                                <td style="text-align: center;">{{$studentschedule->schedule->section->name}} </td>
                                <td style="text-align: center;">{{$studentschedule->schedule->section->teacher->fullname}}</td>
                                    
                                <td style="text-align: center;">{{$studentschedule->schedule->room->name}}</td>
                            </tr>
                           
                            
							</tbody>

	</table>







</body>
</html>
