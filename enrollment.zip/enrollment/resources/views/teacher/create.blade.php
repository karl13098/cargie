@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        
        <div class="row">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('teacher.store') }}">
		
		@csrf
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	<h2>Personal Information</h2>
		<tr>
			<td><input type="text" name="lastname" placeholder="Last Name" required><sup class="text-danger">*</sup></td>
			<td><input type="text" name="firstname" placeholder="First Name" required><sup class="text-danger">*</sup></td>
			<td><input type="text" name="middlename" placeholder="Middle Name" required><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td><input type="email" name="email" placeholder="Email" required><sup class="text-danger">*</sup></td>
			<td><input type="number" name="mobile" placeholder="Mobile No." required><sup class="text-danger">*</sup></td>
			<td><input type="number" name="telephone" placeholder="Telephone No."></td>
		</tr>
		<tr>
			<td><select name="gender" class="form-control" required>
				<option value="">Select Gender</option>
				<option value="male">Male</option>
				<option value="female">Female</option>
				</select><sup class="text-danger">*</sup></td>
		</tr>
		
		<tr>
		<div class="form-group">
			<td><a href="{{route('teacher.index')}}" class="btn btn-sm btn-success">Back</a></td>
			<td><button type="submit" class="btn btn-sm btn-primary">Create</button></td>

		</div>
	</tr>

	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

@endsection

