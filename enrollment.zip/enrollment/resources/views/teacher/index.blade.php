@extends('layout')
@section('content')

    <div class="content-wrapper">
        
        @if($message = Session::get('success'))
            <div class="alert alert-success">
                {{ $message }}
            </div>
        @endif
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table<a class="btn btn-success" href="{{route('teacher.create')}}" style="margin-left: 800px">Create New</a></h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row" >
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                
                                <th>Name</th>
                                <th>Email</th>
                                <th>Actions</th>
                                
                                
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($teachers as $teacher)
                            <tr>
                                
                                <td>{{$teacher->fullname}}</td>
                                <td>{{$teacher->email}}</td>
                                
                                


                                <td>
                                    <form action="{{route('teacher.destroy',$teacher->id)}}" method="post">
                                    <a class="btn btn-sm btn-primary" href="{{route('teacher.show',$teacher->id)}}">VIEW</a>
                                    <a class="btn btn-sm btn-secondary" href="{{route('teacher.edit',$teacher->id)}}">EDIT</a>
                                @csrf
                                @method('DELETE')
                                  <button class="btn btn-outline-danger" onclick=" return confirm('Are you sure?')">DELETE</button>   
                               
                            </form>
                                </td>
                            </tr>
                                @endforeach


                            </tbody>
                        </table>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

  @endsection