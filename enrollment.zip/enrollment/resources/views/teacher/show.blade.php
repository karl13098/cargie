@extends('layout')

@section('content')
	  <div class="content-wrapper">
        <h1 class="page-title">Personal Information</h1>
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">
				<tr>
					<td><strong>Full Name:</strong></td>
					<td>{{$teacher->fullname}}</td>
				</tr>
				
				<tr>
					<td><strong>Gender:</strong></td>
					<td>{{$teacher->gender}}</td>
				</tr>

				<tr>
					<td><strong>Email:</strong></td>
					<td>{{$teacher->email}}</td>
				</tr>
				<tr>
					<td><strong>Mobile No:</strong></td>
					<td>{{$teacher->mobile}}</td>
				</tr>
				<tr>
					<td><strong>Telephone No:</strong></td>
					<td>{{$teacher->telephone}}</td>
				</tr>
	
	
	
				
			
			<tr>
			<td><a href="{{route('teacher.index')}}" class="btn btn-sm btn-success">back</a></td>
		</tr>

</table>
</div>
</div>
</div>
</div>
</div>

@endsection