@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        <h1 class="page-title">School Fees</h1>
                     
 	 @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
	@endif



        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                   
   
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('tuitionfees.store') }}">
		
		@csrf
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr><td><label>Course:</label></td>
			<td><select class="form-control" name="course" style="width: 350px">
					<option value="">--Select--</option>
					@foreach($courses as $course)
						<option value="{{ $course->id }}">{{ $course->name }} {{$course->types}}</option>
					@endforeach
				</select>
			</td>
		</tr>
		<tr>
			<td><label>Enrollment Fee:</label></td>
			<td><input type="number" name="enrollment_fee" size="50" required min="0" step="0.01"></td>
		</tr>

		<tr>
			<td><label>Tuition Fee:</label></td>
			<td><input type="number" name="tuition_fee" size="50" required min="0" step="0.01"></td>
		</tr>

		<tr>
			<td><label>laboratory Fee:</label></td>
			<td><input type="number" name="laboratory_fee" size="50" required min="0" step="0.01"></td>
		</tr>

		<tr>
			<td><label>Records, Registration, T O R:</label></td>
			<td><input type="number" name="registration" size="50" required min="0" step="0.01"></td>
		</tr>

		<tr>
			<td><label>Assessment Fee:</label></td>
			<td><input type="number" name="assessment_fee" size="50" required min="0" step="0.01"></td>
		</tr>

		
		<tr><td><div class="form-control">
			<td><a href="{{route('tuitionfees.index')}}" class="btn btn-sm btn-success">Back</a>
			</td>
			<td><td><button type="submit" class="btn btn-sm btn-primary">Create</button>

		</td>
	</div>
	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

@endsection

