@extends('layout')
@section('content')
	



	<div class="content-wrapper">
        <h1 class="page-title">School Fees</h1>
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="{{ route('tuitionfees.update',$tuitionfee->id) }}">
		
		@csrf
		@method('PUT')
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr><td><label>Course</label></td>
			<td><select class="form-control" name="course" style="width: 400px" >
					
					@foreach($courses as $course)
					@if($course->id == $tuitionfee->course->id)

						<option selected value="{{ $tuitionfee->course_id }}">{{ $course->name }} {{$course->types}}</option>
					@else
						
					@endif
					
					@endforeach
		</tr>
		<tr>
			<td><label>Enrollment Fee:</label></td>
			<td><input type="number" name="enrollment_fee" size="50" value="{{$tuitionfee->enrollment_fee}}" required></td>
		</tr>

		<tr>
			<td><label>Tuition Fee:</label></td>
			<td><input type="number" name="tuition_fee" size="50" value="{{$tuitionfee->tuition_fee}}" required></td>
		</tr>

		<tr>
			<td><label>laboratory Fee:</label></td>
			<td><input type="number" name="laboratory_fee" size="50" value="{{$tuitionfee->laboratory_fee}}" required></td>
		</tr>

		<tr>
			<td><label>Records, Registration, T O R:</label></td>
			<td><input type="number" name="registration" size="50" value="{{$tuitionfee->registration}}" required></td>
		</tr>

		<tr>
			<td><label>Assessment Fee:</label></td>
			<td><input type="number" name="assessment_fee" value="{{$tuitionfee->assessment_fee}}" size="50" required></td>
		</tr>

		
		<tr>
			<td>
				<a href="{{route('tuitionfees.index')}}" class="btn btn-sm btn-success">Back</a>
			</td><td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>

		</td>

	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

@endsection

