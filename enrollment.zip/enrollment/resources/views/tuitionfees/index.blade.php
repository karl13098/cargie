@extends('layout')
@section('content')



    <div class="content-wrapper">
        <!-- <h1 class="pull-right">
           <a class="btn btn-primary pull-right" href="" style="margin-top: -10px;margin-bottom: 5px">Enroll Student</a>
        </h1>-->
        @if($message = Session::get('success'))
            <div class="alert alert-success">
                {{ $message }}
            </div>
        @endif
           @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

        
        <div class="card">
            <div class="card-body">
                
                <h2 class="card-title">Data table  <a class="btn btn-success" href="{{route('tuitionfees.create')}}" style="margin-left: 800px">Create New</a></h2>
                <p class="alert-success">
                    @foreach($errors->all() as $e)
                        <p>{{$e}}</p>
                    @endforeach
                </p>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                            
                                <th>Course</th>
                                <th>Enrollment Fee</th>
                                <th>Tuition Fee</th>
                                <th>Laboratory Fee</th>
                                <th>Records, Registration, T O R</th>
                                <th>Assessment Fee</th>
                                <th>Actions</th>
                                
                            
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($tuitionfees as $tuitionfee)
                            <tr>

                                <td>{{$tuitionfee->course->name}}</td>
                                <td>{{$tuitionfee->enrollment_fee}}</td>
                                <td>{{$tuitionfee->tuition_fee}}</td>
                                <td>{{$tuitionfee->laboratory_fee}}</td>
                                <td>{{$tuitionfee->registration}}</td>
                                <td>{{$tuitionfee->assessment_fee}}</td>
                                
                                  
                                  <td>
                                    
                                    <form action="{{route('tuitionfees.destroy',$tuitionfee->id)}}" method="post">
                                    
                                    <a class="btn btn-sm btn-secondary" href="{{route('tuitionfees.edit',$tuitionfee->id)}}">EDIT</a>
                                @csrf
                                @method('DELETE')
                                 <button  class="btn btn-outline-danger" onclick=" return confirm('Are you sure?')" 
                     >DELETE</button>
                                
                            </form>
                                </td>
                            </tr>
                                @endforeach


                            </tbody>
                        </table>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

  @endsection