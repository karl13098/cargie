<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');

})->middleware('auth');


Auth::routes(['verify' => true]);

Route::get('/home', 'HomeController@index')->name('home');


Route::resource('users', 'UserController');


Route::resource('reservations','ReservationController');

Route::resource('requirements','RequirementController');

Route::resource('teacher','TeacherController');

Route::resource('courses','CourseController');

Route::resource('scholarships','ScholarshipController');

Route::resource('semester','SemesterController');

Route::resource('enrollments','EnrollmentController');

Route::resource('sections','SectionController');

Route::resource('rooms','RoomController');

Route::resource('school_years','School_YearController');

Route::resource('students','StudentController');

Route::resource('schedules','ScheduleController');

Route::resource('studentschedules','StudentscheduleController');

Route::resource('studentrequirements','StudentrequirementController');

Route::resource('tuitionfees','TuitionfeeController');

Route::resource('fees','feeController');

// Student Profile Setting



/*
Route :: get ('/addstudent','AddstudentsController@addstudent');
Route :: post ('/save_student','AddstudentsController@save_student');
Route :: get ('/allstudent','AllstudentsController@allstudent');
Route :: get ('/student_delete/{student_id}','AllstudentsController@studentdelete');
Route :: get ('/student_view/{student_id}','AllstudentsController@studentview');
Route :: get ('/student_edit/{student_id}','AllstudentsController@studentedit');
Route :: post ('/update_student/{student_id}','AllstudentsController@studentupdate');

// tution fee...........

Route :: get ('/tutionfee','TutionfeeController@tutionfee');

// All Course ...........

Route :: get ('/EventsManagementServices','EVENTSMANAGEMENTSERVICESController@ems');
Route :: get ('/Bookkeeping','BOOKKEEPINGController@Bookkeeping');
Route :: get ('/FoodAndBeveragesServices','FOODANDBEVERAGESERVICESController@foodandbeverageservices');


// All teacher........

Route :: get ('/allteacher','AllteacherController@allteacher');
Route :: get ('/addteacher','AllteacherController@addteacher');
Route :: post ('/save_teacher','AllteacherController@saveteacher');
*/




