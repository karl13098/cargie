<?php $__env->startSection('content'); ?>
<p><?php echo e($user->email); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/users/show.blade.php ENDPATH**/ ?>