<?php $__env->startSection('content'); ?>



    <div class="content-wrapper">
        <!-- <h1 class="pull-right">
           <a class="btn btn-primary pull-right" href="" style="margin-top: -10px;margin-bottom: 5px">Enroll Student</a>
        </h1>-->

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
    
        
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table  <a class="btn btn-success" href="<?php echo e(route('sections.create')); ?>" style="margin-left: 800px">Create New</a></h2> 
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>

                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-sm" style="width:100%;" onclick="">
                            <thead>
                            <tr>
                               
                                <th>Name</th>
                                <th>Description</th>
                                <th>Teacher</th>
                                <th>Actions</th>
                                
                            
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><?php echo e($section->name); ?></td>
                                <td><?php echo e($section->description); ?></td>
                                <td><?php echo e($section->teacher->fullname); ?></td>
                                
                               


                                <td>
                                    <form action="<?php echo e(route('sections.destroy',$section->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                   
                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(route('sections.edit',$section->id)); ?>">EDIT</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                     <button  class="btn btn-outline-danger" onclick=" return confirm('Are you sure?')" 
                     >DELETE</button>
                                
                            </form>
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/sections/index.blade.php ENDPATH**/ ?>