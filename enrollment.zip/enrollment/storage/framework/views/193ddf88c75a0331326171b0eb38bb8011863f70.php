<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <h1 class="page-title">Data table</h1>
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                <th>St_roll</th>
                                <th>St_name</th>
                                <th>Phone</th>
                                <th>Image</th>
                                <th>Address</th>
                                <th>Department</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $all_eng_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($v_student->student_roll); ?></td>
                                    <td><?php echo e($v_student->student_name); ?></td>
                                    <td><?php echo e($v_student->student_phone); ?></td>
                                    <td><img src="<?php echo e(URL :: to($v_student->student_image)); ?>" height="80" width="100" style="border-radius: 50%"></td>
                                    <td><?php echo e($v_student->student_address); ?></td>
                                    <td>
                                        <?php if($v_student->student_department==1): ?>
                                            <span class="label label-success"><?php echo e('SWE'); ?></span>
                                        <?php elseif($v_student->student_department==2): ?>
                                            <span class="label label-success"><?php echo e('CSE'); ?></span>
                                        <?php elseif($v_student->student_department==3): ?>
                                            <span class="label label-success"><?php echo e('BBA'); ?></span>
                                        <?php elseif($v_student->student_department==4): ?>
                                            <span class="label label-success"><?php echo e('EEE'); ?></span>
                                        <?php elseif($v_student->student_department==5): ?>
                                            <span class="label label-success"><?php echo e('ENG'); ?></span>
                                        <?php endif; ?>
                                    </td>



                                    <td>
                                        <button class="btn btn-outline-primary">View</button>
                                        <button class="btn btn-outline-warning">Edit</button>
                                        <button class="btn btn-outline-danger">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/enroll/eng.blade.php ENDPATH**/ ?>