<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <h1 class="page-title">Data table</h1>
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Student Name</th>
                                <th>Email</th>
                                <th>Course</th>
                                <th>Address</th>
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($v_student->id); ?></td>
                                <td><?php echo e($v_student->fullname); ?></td>
                                <td><?php echo e($v_student->email); ?></td>
                                <td><?php echo e($v_student->course); ?></td>
                                <td><?php echo e($v_student->fulladdress); ?></td>


                                <td>
                                    <a href="<?php echo e(URL :: to('/students/'.$v_student->id)); ?>"><button class="btn btn-outline-primary">View</button></a>
                                    <a href="<?php echo e(URL :: to('/student_edit/'.$v_student->id)); ?>"><button class="btn btn-outline-warning">Edit</button></a>
                                    <a href="<?php echo e(URL :: to('/student_delete/'.$v_student->id)); ?>" id="delete"><button class="btn btn-outline-danger">Delete</button></a>
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/student/index.blade.php ENDPATH**/ ?>