<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        
        <div class="row">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('students.store')); ?>">
		
		<?php echo csrf_field(); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	<h2>Personal Information</h2>
		<tr>
			<td><input type="text" name="lastname" placeholder="Last Name" required><sup class="text-danger">*</sup></td>
			<td><input type="text" name="firstname" placeholder="First Name" required><sup class="text-danger">*</sup></td>
			<td><input type="text" name="middlename" placeholder="Middle Name" required><sup class="text-danger">*</sup></td>
		</tr>
		

		<tr>
			<td>
				<select name="gender" class="form-control" required style="width: 185px"> 
				<option value="">Select Gender</option>
				<option value="male">Male</option>
				<option value="female">Female</option>
				</select><sup class="text-danger">*</sup>
			</td>
			<td><label style="font-size: 10px">Birthdate</label>
				<input type="date" name="birthdate" placeholder="Date Of Birth" style="width: 140px" required><sup class="text-danger">*</sup></td>
			<td>
				<select name="nationality" class="form-control" style="width: 185px" required>
					<option value="">Nationality</option>
					<option value="filipino">Filipino</option>
					<option value="foreigner">Foreigner</option>
				</select><sup class="text-danger">*</sup>
			</td>
		</tr>


		<tr>
			<td><label >Birthplace</label></td><td>
				
			
			<input type="text" name="birthplaceprovince" placeholder="Province" required><sup class="text-danger">*</sup></td>
			<td><input type="text" name="birthplacecity" placeholder="City/Municipality"required><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td>
				
				<select class="form-control" name="civilstatus" required style="width: 185px">
					<option value="">Select Civil Status</option>
					<option value="single">Single</option>
					<option value="married">Married</option>
					<option value="widower">Widower</option>
					<option value="separated">Separated</option>
					<option value="soloparent">Solo Parent</option>
				</select><sup class="text-danger">*</sup>
			</td>
			<td>
				<label for="employment" style="font-size: 10px">Employment Status</label></td><td>
				<input type="radio" name="employment" value="employed">Employed
				<input type="radio" name="employment" value="unemployed">Unemployed
			</td>
		</tr>

		
	</table>
</div>
<div class="form-group">
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Contact Information</h2>
		<tr>
			<td><input type="text" name="street" placeholder="Street" required><sup class="text-danger">*</sup></td>
			<td><input type="text" name="barangay" placeholder="Barangay" required><sup class="text-danger">*</sup></td>
			
		</tr>
		<tr>
			<td><input type="text" name="province" placeholder="Province" required><sup class="text-danger">*</sup></td>
			<td><input type="text" name="city" placeholder="City/Municipality" required><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td><input type="email" name="email" placeholder="Email Address" required><sup class="text-danger">*</sup></td>
			<td><input type="number" name="mobile" placeholder="Mobile No" required ><sup class="text-danger">*</sup></td>
			<td><input type="number" name="telephone" placeholder="Telephone No" ></td>
		</tr>
	</table>
</div>
<div class="form-group">

	 <table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Other Information</h2>
		<tr>
			
				<label>Parents/Guardian:</label>
				<td><input type="text" name="parentguardianname" placeholder="Full Name" size="30" required><sup class="text-danger">*</sup>

			</td>
			<td><input type="text" name="mailingaddress" placeholder="Complete Permanent Mailing Address" size="40" required><sup class="text-danger">*</sup></td>
		</tr>
		
	</table>
</div>
<div class="form-group">
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Educational Background</h2>
		<tr>
			<td><input type="radio" name="education" value="High School Graduate">High School Graduate</td>
			<td><input type="radio" name="education" value="College Level">College Level</td>
			<td><input type="radio" name="education" value="College Graduate">College Graduate</td>
		</tr>
	</table>
</div>

<div class="form-group">
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Name of Course/Qualification</h2>
		
		<tr>

			<td>
				
				<select class="form-control" name="course_id" style="width: 400px">
					<option value="">Select Course</option>
					<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?> <?php echo e($course->types); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select><sup class="text-danger">*</sup>

			</td>
		</tr>


			<tr>

			<td>
				
				<select class="form-control" name="scholarship_id" style="width: 300px">
					<option value="">Select Scholarship</option>
					<?php $__currentLoopData = $scholarships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scholarship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($scholarship->id); ?>"><?php echo e($scholarship->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

			</td>
		</tr>
	</table>
</div>
<!--
<div class="form-group">
	<table>
		<h2>If Scholar, What Type of Scholarship Package</h2>
		<tr>
			<td>
				<input type="radio" name="scholarship" value="TWSP">TWSP
				<input type="radio" name="scholarship" value="PESFA">PESFA
				<input type="radio" name="scholarship" value="STEP">STEP
				<input type="radio" name="scholarship" value="Others">Others
				<input type="radio" name="scholarship" value="none">None

			</td>
		</tr>
	</table>
</div>-->
<tr>
		<div class="form-group">
			<td><a href="<?php echo e(route('students.index')); ?>" class="btn btn-sm btn-success">Back</a></td>
			<td><button type="submit" class="btn btn-sm btn-primary">Create</button></td>

		</div>
</tr>
	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/students/create.blade.php ENDPATH**/ ?>