<?php $__env->startSection('content'); ?>
	  <div class="content-wrapper">
        
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <div class="row">
                    <div class="col-12">
                        <table class="table table-bordered" style="width: 600px" >


	
				
				<tr>
					<td><strong>Course:</strong></td>
					<td><?php echo e($schedule->course->name); ?></td>
					<td>
				</tr>
				<tr>
					<td><strong>Days:</strong></td>
					<td>
                   		 <?php $__currentLoopData = $schedule->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <span ><?php echo e($dayss); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </td>
                   <td >
                  		<?php $__currentLoopData = $schedule->day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <span ><?php echo e($da); ?></span>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </td>
				</tr>
	
				
	
				<tr>
					<td><strong>Time:</strong></td>
					<td><?php echo e($schedule->start_time_AM); ?>  <?php echo e($schedule->end_time_AM); ?> <br>
                                    <?php echo e($schedule->start_time_PM); ?>  <?php echo e($schedule->end_time_PM); ?>


                    </td>
                    <td><?php echo e($schedule->start_time_AMA); ?>  <?php echo e($schedule->end_time_AMA); ?> <br>
                                    <?php echo e($schedule->start_time_PMA); ?>  <?php echo e($schedule->end_time_PMA); ?>


                   </td>
				</tr>

				
				
				
				<tr>
					
					<td><strong>Section:</strong></td>
					<td><?php echo e($schedule->section->name); ?> <?php echo e($schedule->section->description); ?></td>
					<td></td>
				
				</tr>
				<tr>
					<td><strong>Teacher:</strong></td>
					<td><?php echo e($schedule->section->teacher->fullname); ?></td>
					<td></td>
				</tr>

				<tr>
					<td><strong>Room:</strong></td>
					<td><?php echo e($schedule->room->name); ?> <?php echo e($schedule->room->description); ?></td
						>
					<td></td>
				</tr>

			
			
				
			
			<tr>
			<td><a href="<?php echo e(route('schedules.index')); ?>" class="btn btn-sm btn-success">Back</a></td>
			
			
		</tr>

</table>

</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/schedules/show.blade.php ENDPATH**/ ?>