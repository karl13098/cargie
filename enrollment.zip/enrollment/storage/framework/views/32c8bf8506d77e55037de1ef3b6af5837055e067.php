<?php $__env->startSection('content'); ?>



    
    <div class="content-wrapper">  
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                <th>ControlNo:</th>         
                                <th>Name</th>  
                                <th>Course</th>  
                                <th>Scholarship</th> 
                                <th>Actions</th>         
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>            
                                <td><?php echo e($student->id); ?></td>    
                                <td><?php echo e($student->fullname); ?></td>
                                <td>
                                    <?php $__currentLoopData = $student->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span ><?php echo e($enrollment->course->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $student->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($enrollment->scholarship->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                   
                                    <a class="btn btn-sm btn-outline-info" href="<?php echo e(route('students.show',$student->id)); ?>">Records</a>
                                    
                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(route('students.edit',$student->id)); ?>">EDIT</a>
                                    
                                    <button class="btn btn-outline-success"
                                      data-target="#registration-form" data-toggle="modal">Add Schedule
                                    </button>        
                                    </td>
                                </form>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

<div class="modal" tabindex="-1" role="dialog" id="registration-form">
  <div class="modal-dialog" role="document">
    <form method="Post" action="<?php echo e(route('studentschedules.store')); ?>">
    <input type="hidden" name="student" value="<?php echo e($student->id); ?>">   
   
    
    <?php echo csrf_field(); ?>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Schedule</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <label for="schedule">Section</label>
            <select name="schedule" id="schedule" class="form-control">
        
                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($schedule->course_id == $enrollment->course_id): ?>
                        <option value="<?php echo e($schedule->id); ?>"><?php echo e($schedule->section->name); ?> <?php echo e($schedule->section->description); ?></option>
                    <?php else: ?>
                    
                    
                        
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><sup class="text-danger">*</sup>

        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button class="btn btn-primary">Submit</button>
      </div>
    </div>

    </form>
  </div>
</div>



                        

                        

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/students/index.blade.php ENDPATH**/ ?>