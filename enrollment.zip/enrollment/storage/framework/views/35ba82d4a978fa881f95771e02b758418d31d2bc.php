<?php $__env->startSection('content'); ?>
	


	<div class="content-wrapper">
        <h1 class="page-title">Enrollment Form</h1>
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('enrollment.store')); ?>">
		
		<?php echo csrf_field(); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table tab-content" >
	
		
		
		<tr>
			

			<td>
				
				<select class="form-control" name="course_id" style="width: 300px">
					<option value="">Select Course</option>
					<?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select><sup class="text-danger">*</sup>

			</td>
		
		</tr>
		<tr>
			<td><p>Name<input type="text" readonly style="margin-left: 35px"></p></td>
			<td><label>Course<input type="text" name="course" style="margin-left: 5px"></label></td>
		</tr>


	</table>
</div>

</form>
			</div>
			</div>
		</p>
		</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/enrollment/create.blade.php ENDPATH**/ ?>