<?php $__env->startSection('content'); ?>
	  <div class="content-wrapper">
        
        <div class="row">
            <div class="card-body">
                
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">
				<tr>
					<td><strong>Name:</strong></td>
					<td><?php echo e($scholarship->name); ?></td>
				</tr>
	
				
	
				<tr>
					<td><strong>Description:</strong></td>
					<td> <?php echo e($scholarship->description); ?></td>
				</tr>
	
				
	
				

			
				
			
			<tr>
			<td><a href="<?php echo e(route('scholarship.index')); ?>" class="btn btn-sm btn-success">back</a></td>
		
		</tr>

</table>
</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/scholarship/show.blade.php ENDPATH**/ ?>