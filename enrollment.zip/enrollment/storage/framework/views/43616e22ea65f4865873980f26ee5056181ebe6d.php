<?php $__env->startSection('content'); ?>
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="alert alert-warning">
			<?php echo e($e); ?>

		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="container">
		<form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<?php echo e(method_field('put')); ?>

			<div class="form-group">
				<label for="name">Name</label>
				<input type="text" name="name"
					class="form-control <?php echo e($errors->has('name') ? 'is-invalid':''); ?>"
					id="name" value="<?php echo e(old('name', $user->name)); ?>"
					required>
				<?php if($errors->has('name')): ?>
					<div class="invalid-feedback">
						<p><?php echo e($errors->first('name')); ?></p>
					</div>
				<?php endif; ?>
			</div>
			<div class="form-group">
				<label for="email">Email</label>
				<input type="email" name="email" class="form-control" id="email"
					required value="<?php echo e(old('email', $user->email)); ?>">
				<?php if($errors->has('email')): ?>
					<div class="invalid-feedback">
						<p><?php echo e($errors->first('email')); ?></p>
					</div>
				<?php endif; ?>
			</div>
			<div class="form-group">
				<label for="password">Password</label>
				<input type="password" name="password" class="form-control" id="password"
					required>
			</div>
			<button class="btn btn-primary">Update</button>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/users/edit.blade.php ENDPATH**/ ?>