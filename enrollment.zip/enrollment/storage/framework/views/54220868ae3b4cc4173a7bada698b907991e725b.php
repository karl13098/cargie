<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        <h1 class="page-title">Scholarship</h1>
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('fees.update',$fee->id)); ?>">
		
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr><td><label>Name:</label></td>
			<td><input type="text" name="name" required value="<?php echo e($fee->name); ?>"><sup class="text-danger">*</sup>
				

			</td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description" size="50" value="<?php echo e($fee->description); ?>"></td>
		</tr>

		<tr>
			<td><label>Fee</label></td>
			<td><input type="decimal(10,2)" min="0" step="0.01" name="fee" required value="<?php echo e($fee->fee); ?>"><sup class="text-danger">*</sup></td>

		</tr>

		<tr>
			<td><a href="<?php echo e(route('fees.index')); ?>" class="btn btn-sm btn-success">Back																	</a>
			</td>
			<td>
				<button type="submit" class="btn btn-sm btn-primary">Create</button>
			</td>
	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/fees/edit.blade.php ENDPATH**/ ?>