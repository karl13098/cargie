<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        
        <div class="row">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('reservations.update',$reservation->id)); ?>">
		
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="fullname" size="35" value="<?php echo e($reservation->student->fullname); ?>" readonly></td>
		</tr>
		<tr>
			<td><label>Email</label></td>
			<td><input type="email" name="email" size="35" value="<?php echo e($reservation->student->email); ?>" readonly></td>
		</tr>

		<tr><td><label>Course</label></td>
			<td><select class="form-control" name="course" style="width: 290px">
					
					<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($course->id == $reservation->course_id): ?>

						<option selected value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
					<?php endif; ?>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

			</td>
		</tr>



		<tr><td><label>Course</label></td>
			<td><select class="form-control" name="scholarship" style="width: 290px">
					
					<?php $__currentLoopData = $scholarships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scholarship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($scholarship->id == $reservation->scholarship_id): ?>

						<option selected value="<?php echo e($scholarship->id); ?>"><?php echo e($scholarship->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($scholarship->id); ?>"><?php echo e($scholarship->name); ?></option>
					<?php endif; ?>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

			</td>
		</tr>
		<tr>
			<td><label>Address</label></td>
			<td><input type="text" name="fulladdress" size="35" value="<?php echo e($reservation->student->fulladdress); ?>" readonly></td>
		</tr>
			
		<div class="form-group">
			<td><a href="<?php echo e(route('reservations.index')); ?>" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/reservations/edit.blade.php ENDPATH**/ ?>