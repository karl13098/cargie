<?php $__env->startSection('content'); ?>



    <div class="content-wrapper">
         <h1 class="pull-right">
           <a class="btn btn-primary pull-right" style="margin-top: -10px;margin-bottom: 5px" href="<?php echo e(route('semester.create')); ?>">Add New</a>
        </h1>
        <h1 class="page-title">Semester</h1>
        
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <div class="row">
                    <div class="col-12">
                        <table id="order-listing" class="table table-striped" style="width:100%;">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Number</th>
                                
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><?php echo e($semesters->id); ?></td>
                                <td><?php echo e($semesters->name); ?></td>
                                <td><?php echo e($semesters->description); ?></td>
                                <td><?php echo e($semesters->number); ?></td>
                                


                                <td>
                                    <form action="<?php echo e(route('semester.destroy',$semesters->id)); ?>" method="post">
                                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('semester.show',$semesters->id)); ?>">View</a>
                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(route('semester.edit',$semesters->id)); ?>">Edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure you?')">Delete</button>
                            </form>
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/semester/index.blade.php ENDPATH**/ ?>