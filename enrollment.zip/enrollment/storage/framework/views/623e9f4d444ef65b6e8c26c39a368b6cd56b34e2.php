<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('studentrequirements.store',$studentrequirement->id)); ?>">
		
		<?php echo csrf_field(); ?>
		<?php echo method_field('put'); ?>
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr>
			<td><label>Name:</label></td>
			<td><select name="student" class="form-control" style="width: 400px">
      	
					<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($studentrequirement->student->id == $student->id): ?>
						<option selected value="<?php echo e($student->id); ?>"><?php echo e($student->fullname); ?></option>
					<?php else: ?>
					<option selected value="<?php echo e($student->id); ?>"><?php echo e($student->fullname); ?></option>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select></td></td>
		</tr>
		<tr>
			<td><label>Requirements</label></td>
			<td><input type="checkbox" name="name[]" Selected value="Birth Certificate/NSO" size="50">Birth Certificate/NSO</td>
			<td><input type="checkbox" name="name[]" Selected value="School Credential" size="50">School Credential</td>
			<td><input type="checkbox" name="name[]" Selected value="Brgy.Clearance" size="50">Brgy. Clearance</td>
		</tr>
		<tr><td><div class="form-group">
			<td><a href="<?php echo e(route('studentrequirements.index')); ?>" class="btn btn-sm btn-success">Back</a>
			</td><td><button type="submit" class="btn btn-sm btn-primary">Save</button>

		</td></div>
	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/studentrequirements/edit.blade.php ENDPATH**/ ?>