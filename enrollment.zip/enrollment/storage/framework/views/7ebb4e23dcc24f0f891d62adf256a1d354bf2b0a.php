<?php $__env->startSection('content'); ?>
	  <div class="content-wrapper">
        
        <div class="row">
            <div class="card-body">
                <h2 class="card-title">Information</h2>
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">

	
				
				<tr>
					<td><strong>Name:</strong></td>
					<td> <?php echo e($reservation->student->fullname); ?></td>
				</tr>
	
				
	
				<tr>
					<td><strong>Email:</strong></td>
					<td><?php echo e($reservation->student->email); ?></td>
				</tr>

				<tr>
					<td><strong>Course:</strong></td>
					<td><?php echo e($reservation->course->name); ?></td>
				</tr>
				<tr>
					<td><strong>Scholarship:</strong></td>
					<td><?php echo e($reservation->scholarship->name); ?></td>
				</tr>
				<tr>
					<td><strong>Address:</strong></td>
					<td> <?php echo e($reservation->student->fulladdress); ?></td>
				</tr>
				<tr>
					
					<td><strong>MobileNo:</strong></td>
					<td><?php echo e($reservation->student->mobile); ?></td>
				
				</tr>
				<tr>
					<td><strong>TelephoneNo:</strong></td>
					<td><?php echo e($reservation->student->telephone); ?></td>
				</tr>

			
			
				
			
			<tr>
			<td><a href="<?php echo e(route('reservations.index')); ?>" class="btn btn-sm btn-success">Back</a></td>
			<td>
				<button class="btn btn-primary"
					data-target="#registration-form" data-toggle="modal">Enroll</button>
			</td>
			
		</tr>

</table>
<div class="modal" tabindex="-1" role="dialog" id="registration-form">
  <div class="modal-dialog" role="document">
  	<form method="Post" action="<?php echo e(route('enrollments.store')); ?>">

	<input type="hidden" name="student" value="<?php echo e($reservation->student_id); ?>">
	<input type="hidden" name="course" value="<?php echo e($reservation->course_id); ?>">
	<input type="hidden" name="scholarship" value="<?php echo e($reservation->scholarship_id); ?>">
	
	<?php echo csrf_field(); ?>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="form-group">
      		<label for="school_year">School Year</label>
      		<select name="school_year" id="school_year" class="form-control">
      	
					<?php $__currentLoopData = $school_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($school_year->id); ?>"><?php echo e($school_year->year); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select><sup class="text-danger">*</sup>

      	</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button class="btn btn-primary">Submit</button>
      </div>
    </div>

	</form>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/reservations/show.blade.php ENDPATH**/ ?>