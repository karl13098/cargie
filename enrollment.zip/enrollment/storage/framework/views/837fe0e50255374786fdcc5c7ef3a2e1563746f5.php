<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                     <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
	<div class="card">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('schedules.store')); ?>">
		
		<?php echo csrf_field(); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	
		<tr>
			<td><label>School Year</label></td>
      		<td><select name="school_year" class="form-control" style="width: 100px">
      	
					<?php $__currentLoopData = $school_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($school_year->id); ?>"><?php echo e($school_year->year); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select></td>
		</tr>
		<tr>

			
				<td><label>Course</label></td>
				<td><select class="form-control" name="course" style="width: 350px">
					<option value="">--Select--</option>
					<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?> <?php echo e($course->types); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

			</td>
		</tr>



		<tr>
			<td><label>Section</label></td>

			<td>
				
				<select class="form-control" name="section" style="width: 300px">
					<option value="">--Select--</option>
					<?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?> <?php echo e($section->description); ?> </option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</td>
		</tr>

	
		<tr>
			<td><label>Room</label></td>

			<td>
				
				<select class="form-control" name="room" style="width: 300px">
					<option value="">--Select--</option>
					<?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</td>
		</tr>


		<tr>
			<td><label>Days</label></td>
			<td><input type="checkbox" value="M" name="days[]">M  
				<input type="checkbox" value="T" name="days[]" style="margin-left: 20px">T
				<input type="checkbox" value="W" name="days[]" style="margin-left: 20px">W
				<input type="checkbox" value="Th" name="days[]" style="margin-left: 20px">Th
				<input type="checkbox" value="F" name="days[]" style="margin-left: 20px">F
			</td>
			<td><input type="checkbox" value="M" name="day[]">M  
				<input type="checkbox" value="T" name="day[]" style="margin-left: 20px">T
				<input type="checkbox" value="W" name="day[]" style="margin-left: 20px">W
				<input type="checkbox" value="Th" name="day[]" style="margin-left: 20px">Th
				<input type="checkbox" value="F" name="day[]" style="margin-left: 20px">F
			</td>
		</tr>

		<tr>
			<td><label>Time(From-To)</label></td>
			<td><input type="time"  name="start_time_AM"
       min="06:00" max="18:00" required>
			
				<input type="time" name="end_time_AM"
       min="06:00" max="18:00" required>
			</td>

			
			<td><input type="time"  name="start_time_AMA"
       min="06:00" max="18:00" >
			
				<input type="time" name="end_time_AMA"
       min="06:00" max="18:00" >
			</td>

			
		</tr>
		<tr>
			<td><label>Time(From-To)</label></td>
			<td><input type="time" name="start_time_PM"
       min="00:00" max="24:00" >
			
				<input type="time" id="appt" name="end_time_PM"
       min="00:00" max="24:00" >
			</td>

			<td><input type="time" name="start_time_PMA"
       min="00:00" max="24:00" >
			
				<input type="time" id="appt" name="end_time_PMA"
       min="00:00" max="24:00" >
			</td>

			
		</tr>
		
		<tr>
			
		<div class="form-group">
			<td><a href="<?php echo e(route('schedules.index')); ?>" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Create</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/schedules/create.blade.php ENDPATH**/ ?>