<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        <h1 class="page-title">Reservation</h1>
        <div class="card">
                   
              
            <div class="card-body">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger">
                        	<?php echo e($e); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('reservation.update',$reservation->id)); ?>">
		
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	<h2>Personal Information</h2>
		<tr><td><label>Full Name:</label></td>
			<td><input type="text" name="name" value ="<?php echo e($reservation->student->fullname); ?>" size="35" readonly></td>
		</tr>
		<tr><td><label>Email:</label>
			<td><input type="email" name="email" value="<?php echo e($reservation->student->email); ?>" size="35" readonly></td>
		</tr>
		<tr><td>Course</td>
			<td><select class="form-control" name="course">
					
					<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($course->id == $reservation->course_id): ?>

						<option selected value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
					<?php endif; ?>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

			</td>
		</tr>
		<tr>
		<div class="form-group">
			<td><a href="<?php echo e(route('reservation.index')); ?>" class="btn btn-sm btn-success">Back</a></td>
			<td><button type="submit" class="btn btn-sm btn-primary">Save</button></td>

		</div>
	</tr>

	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/reservation/edit.blade.php ENDPATH**/ ?>