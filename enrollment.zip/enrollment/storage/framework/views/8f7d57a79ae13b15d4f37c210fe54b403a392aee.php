<!DOCTYPE html>
<html>

<head>
    <style>
        table{
            border-collapse: collapse;
        }

        table,th,td {
            border: 1px solid black;
        }
        input{
            background: transparent;
            border: none;
            font-weight: bold;
        }

    </style>

	
	<div >
	<h2 style="text-align: center;margin-top: 100px">CMC INSTITUTE OF BUSINESS MANAGEMENT <br>SKILLS TRAINING AND ASSESSMENT CENTER INC.</h2><h5 style="text-align: center">SEC. REG. CN201945172 <br>Business Address:J.A. Clarin Street, Poblacion III Tagbilaran City <br>Email Address:cmc.skillsinstitute@gmail.com madulara@yahoo.com</h5></div>
	
</head>
<body>
	<table  width="100%">
		
			<tr>
				<td>StudentID: <input type="text" name="" value="<?php echo e($studentschedule->student->id); ?>" style="margin-left: 50px"></td>	
				<td>School year:<input type="text" name="" value="<?php echo e($studentschedule->schedule->school_year->year); ?>"  style="margin-left: 50px"></td>			
			</tr>
			<tr>
				<td>Name:<input type="text" name="" value="<?php echo e($studentschedule->student->fullname); ?>"  style="margin-left: 80px"></td>
                <td>Scholarship: <?php $__currentLoopData = $studentschedule->student->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span style="margin-left: 45px"><?php echo e($enrollment->scholarship->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>

			</tr>

		
		
	</table>
	<table id="order-listing" class="table table-sm" style="width:100%;border-collapse: collapse;border: 1px solid black;">
                            <thead>
                            <tr>
                                
                                <th>Course</th>
                                <th>Type</th>
                                <th>Time</th>
                                <th>Day</th>
                                <th>Section</th>
                                
                                <th>Teacher</th>
                                <th>Room</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->course->name); ?></td>

                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->course->types); ?></td>
                               <td style="text-align: center;"><?php echo e($studentschedule->schedule->start_time_AM); ?>  <?php echo e($studentschedule->schedule->end_time_AM); ?> <br>
                                    <?php echo e($studentschedule->schedule->start_time_PM); ?>  <?php echo e($studentschedule->schedule->end_time_PM); ?>


                                </td>
                                <td style="text-align: center;">
                                   <?php $__currentLoopData = $studentschedule->schedule->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span ><?php echo e($day); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->section->name); ?> </td>
                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->section->teacher->fullname); ?></td>
                                    
                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->room->name); ?></td>
                            </tr>
                             <tr>
                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->course->name); ?></td>

                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->course->types); ?></td>
                               <td style="text-align: center;"><?php echo e($studentschedule->schedule->start_time_AMA); ?>  <?php echo e($studentschedule->schedule->end_time_AMA); ?> <br>
                                    <?php echo e($studentschedule->schedule->start_time_PMA); ?>  <?php echo e($studentschedule->schedule->end_time_PMA); ?>


                                </td>
                                <td style="text-align: center;">
                                   <?php $__currentLoopData = $studentschedule->schedule->day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span ><?php echo e($da); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->section->name); ?> </td>
                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->section->teacher->fullname); ?></td>
                                    
                                <td style="text-align: center;"><?php echo e($studentschedule->schedule->room->name); ?></td>
                            </tr>
                           
                            
							</tbody>

	</table>







</body>
</html>
<?php /**PATH C:\laragon\www\enrollment\resources\views/studentschedules/show.blade.php ENDPATH**/ ?>