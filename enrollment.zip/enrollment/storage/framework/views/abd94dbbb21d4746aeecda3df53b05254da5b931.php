<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="row">
        <div class="col-sm-6 col-md-3 grid-margin">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Reservation</h2>
                    <?php
                    $reservations = DB::table('reservations')
                    ->count('id');
                    ?>
                    <p style="font-family: cursive; font-size: 22px; color: red; text-align: center"><?php echo e($reservations); ?></p>
                </div>
                <div class="dashboard-chart-card-container">
                    <div id="dashboard-card-chart-1" class="card-float-chart"></div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-3 grid-margin">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Teachers</h2>
                    <?php
                        $teacher = DB::table('teachers')
                        ->count('id');
                        
                    ?>
                    <p style="font-family: cursive; font-size: 22px; color: red; text-align: center"><?php echo e($teacher); ?></p>
                </div>
                <div class="dashboard-chart-card-container">
                    <div id="dashboard-card-chart-2" class="card-float-chart"></div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-3 grid-margin">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Students</h2>
                    <?php
                        $studentschedules = DB::table('studentschedules')
                        ->count('id');
                        
                    ?>
                    <p style="font-family: cursive; font-size: 22px; color: red; text-align: center"><?php echo e($studentschedules); ?></p>
                </div>
                <div class="dashboard-chart-card-container">
                    <div id="dashboard-card-chart-2" class="card-float-chart"></div>
                </div>
            </div>
        </div>
        
       




    </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/home.blade.php ENDPATH**/ ?>