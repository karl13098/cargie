<?php $__env->startSection('content'); ?>
	  <div class="content-wrapper">
        
        <div class="row">
            <div class="card-body">
                <h2 class="card-title">Student Information</h2>
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">

	
				
	
				<tr>
					<td><strong>Name:</strong></td>
					<td> <?php echo e($student->fullname); ?></td>
				</tr>

				<tr>
					<td><strong>Gender:</strong></td>
					<td> <?php echo e($student->gender); ?></td>
				</tr>

				<tr>
					<td><strong>Employment:</strong></td>
					<td> <?php echo e($student->employment); ?></td>
				</tr>




				<tr>
					<td><strong>Email:</strong></td>
					<td> <?php echo e($student->email); ?></td>
				</tr>

				<tr>
					<td><strong>Address:</strong></td>
					<td> <?php echo e($student->fulladdress); ?></td>
				</tr>

				<tr>
					<td><strong>Mobile No:</strong></td>
					<td> <?php echo e($student->mobile); ?></td>
				</tr>


				<tr>
					<td><strong>Parent/Guardian:</strong></td>
					<td> <?php echo e($student->parentguardianname); ?></td>
				</tr>

				<tr>
					<td><strong>Complete Mailing Address:</strong></td>
					<td> <?php echo e($student->mailingaddress); ?></td>
				</tr>
	
				
	
				<tr>
					<td><strong>Course:</strong></td>
					<td>
                                    <?php $__currentLoopData = $student->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span ><?php echo e($enrollment->course->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
				</tr>

				<tr>
					<td><strong>Scholarship:</strong></td>
					 <td>
                                    <?php $__currentLoopData = $student->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($enrollment->scholarship->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
				</tr>
				

			
				
			
			<tr>
			<td><a href="<?php echo e(route('students.index')); ?>" class="btn btn-sm btn-success">Back</a></td>
			<td>
				<button class="btn btn-outline-success"
                                      data-target="#registration-form" data-toggle="modal">Add Schedule
                                    </button>
			</td>
			
				
		</tr>

</table>

<div class="modal" tabindex="-1" role="dialog" id="registration-form">
  <div class="modal-dialog" role="document">
    <form method="Post" action="<?php echo e(route('studentschedules.store')); ?>">
    <input type="hidden" name="student" value="<?php echo e($student->id); ?>">	
   
    
    <?php echo csrf_field(); ?>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Schedule</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <label for="schedule">Section</label>
            <select name="schedule" id="schedule" class="form-control">
        
                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($schedule->course_id == $enrollment->course_id): ?>
                        <option value="<?php echo e($schedule->id); ?>"><?php echo e($schedule->section->name); ?> <?php echo e($schedule->section->description); ?></option>
                    <?php else: ?>
                    
                    
                        
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><sup class="text-danger">*</sup>

        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button class="btn btn-primary">Submit</button>
      </div>
    </div>

    </form>
  </div>
</div>


</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/students/show.blade.php ENDPATH**/ ?>