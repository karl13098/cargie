<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        <h1 class="page-title">Registration Form</h1>
          <div class="row">
                    <div class="col-12 col-lg-6 grid-margin">
            <div class="card-body">
               
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
              
	
	<form class="forms-sample" method="post" action="<?php echo e(route('students.create')); ?>" enctype="multipart/form-data" >
		<fieldset>
		<?php echo csrf_field(); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	<h2>Personal Information</h2>
		<tr>
			<td><input type="text" name="lastname" placeholder="Last Name*"></td>
			<td><input type="text" name="firstname" placeholder="First Name*"></td>
			<td><input type="text" name="middlename" placeholder="Middle Name"></td>
		</tr>
		<tr>
			<td><input type="text" name="middleinitial" placeholder="Middle Initial"></td>
			
			<td><input type="text" name="extensionname" placeholder="Extension Name(e.g Jr,Sr)"></td>
		</tr>

		<tr>
			<td>
				<select name="gender" style="width: 183px">
				<option>Gender</option>
				<option value="male">Male</option>
				<option value="female">Female</option>
				</select>
			</td>
			<td><label style="font-size: 10px">Birthdate</label>
				<input type="date" name="birthdate" placeholder="Date Of Birth (mm/dd/yyyy)"></td>
			<td>
				<select name="nationality" style="width: 183px">
					<option>Nationality</option>
					<option value="filipino">Filipino</option>
					<option value="foreigner">Foreigner</option>
				</select>
			</td>
		</tr>


		<tr>
			<td><label>Birthplace:*</label></td><td>
				<input type="text" name="birthplaceregion" placeholder="Region">
			</td>
			<td><input type="text" name="birthplaceprovince" placeholder="Province"></td>
			<td><input type="text" name="birthplacecity" placeholder="City"></td>
		</tr>
		<tr>
			<td>
				<label>Civil Status</label>
				<select for=civilstatus>
					<option value="single">Single</option>
					<option value="married">Married</option>
					<option value="widower">Widower</option>
					<option value="separated">Separated</option>
					<option value="soloparent">Solo Parent</option>
				</select>
			</td>
			<td>
				<label for="employment" style="font-size: 10px">Employment Status</label></td><td>
				<input type="radio" name="employment" value="employed">Employed
				<input type="radio" name="employment" value="unemployed">Unemployed
			</td>
		</tr>

		
	</table>
</div>
<div class="form-group">
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Contact Information</h2>
		<tr>
			<td><input type="text" name="street" placeholder="Street"></td>
			<td><input type="text" name="barangay" placeholder="Barangay"></td>
			<td><input type="text" name="district" placeholder="District"></td>
		</tr>
		<tr>
			<td><input type="text" name="region" placeholder="Region"></td>
			<td><input type="text" name="province" placeholder="Province"></td>
			<td><input type="text" name="city" placeholder="City"></td>
		</tr>
		<tr>
			<td><input type="email" name="email" placeholder="Email Address"></td>
			<td><input type="text" name="mobile" placeholder="Mobile No"></td>
			<td><input type="text" name="telephone" placeholder="Telephone No"></td>
		</tr>
	</table>
</div>
<div class="form-group">

	 <table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Other Information</h2>
		<tr>
			
				<label>Parents/Guardian:</label>
				<td><input type="text" name="parentguardianname" placeholder="Full Name" size="30">

			</td>
			<td><input type="text" name="mailingaddress" placeholder="Complete Permanent Mailing Address" size="40"></td>
		</tr>
		
	</table>
</div>
<div class="form-group">
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Educational Attaintment Before the Training(Trainee)</h2>
		<tr>
		
				<label>High School</label>
			<td>	<input type="text" name="nameofschool" placeholder="Name of School" size="35">
			</td>
			<td><input type="text" name="placeofschool" placeholder="Place of School" size="35"></td>
		</tr>
	</table>
</div>
<div class="form-group">
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Name of Course/Qualification</h2>
		<tr>
			<td>
				<label for="course">Course</label>
				<select name="course">
					<option value="eventsmanagementservicesnciii">Events Management Services NCIII</option>
					<option value="bookkeepingnciii">Bookkeeping NCIII</option>
					<option value="foodandbeveragenciii">Food and Beverage Services NCIII</option>
				</select>

			</td>
		</tr>
	</table>
</div>
<div class="form-group">
	<table>
		<h2>If Scholar, What Type of Scholarship Package</h2>
		<tr>
			<td>
				<input type="radio" name="scholarship" value="twsp">TWSP
				<input type="radio" name="scholarship" value="pesfa">PESFA
				<input type="radio" name="scholarship" value="step">STEP
				<input type="radio" name="scholarship" value="others">Others
				<input type="radio" name="scholarship" value="others">None

			</td>
		</tr>
	</table>
</div>

		<tr>
				
				<td><input type="submit" name="submit" ></td>
			
		</tr>

	</table>
</div>
</fieldset>
</form>
			</div>
		</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/student/create.blade.php ENDPATH**/ ?>