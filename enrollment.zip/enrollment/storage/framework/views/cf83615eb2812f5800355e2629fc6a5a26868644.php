<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        <h1 class="page-title">Scholarship</h1>
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('scholarship.store')); ?>">
		
		<?php echo csrf_field(); ?>
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		<h2>Types of Scholarship</h2>
		<tr><td><label>Name:</label></td>
			<td><input type="text" name="name" required><sup class="text-danger">*</sup>
				

			</td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description" required><sup class="text-danger">*</sup></td>
		</tr>
		<tr><td><div class="form-group">
			<td><a href="<?php echo e(route('scholarship.index')); ?>" class="btn btn-sm btn-success">Back</a>
			</td><td><td><button type="submit" class="btn btn-sm btn-primary">Create</button>

		</td></div>
	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/scholarship/create.blade.php ENDPATH**/ ?>