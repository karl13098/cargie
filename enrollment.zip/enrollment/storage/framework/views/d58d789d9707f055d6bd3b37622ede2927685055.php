<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        
        <div class="column">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                     <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('schedules.update',$schedule->id)); ?>">
		
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	
		<tr>
			<td><label>School Year</label></td>
      		<td><select name="school_year" class="form-control" style="width: 100px">
      	
					<?php $__currentLoopData = $school_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($school_year->id); ?>"><?php echo e($school_year->year); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select></td>
		</tr>
		<tr>

			
				
				<td><label>Course</label></td>
			<td><select class="form-control" name="course" style="width: 490px" >
					
					<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($course->id == $schedule->course->id): ?>

						<option selected value="<?php echo e($schedule->course->id); ?>"><?php echo e($schedule->course->name); ?> <?php echo e($schedule->course->types); ?></option>
					<?php else: ?>
						
					<?php endif; ?>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

			</td>
		</tr>

		<tr>
			<td><label>Section</label></td>

			<td>
				
				<select class="form-control" name="section" style="width: 490px">
					
					<?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($section->id == $schedule->section->id): ?>
						<option selected value="<?php echo e($schedule->section->id); ?>"><?php echo e($schedule->section->name); ?> <?php echo e($schedule->section->description); ?></option>
					<?php else: ?> 
					<?php endif; ?>
						
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</td>
		</tr>

	
		<tr>
			<td><label>Room</label></td>

			<td>
				
				<select class="form-control" name="room" style="width: 400px">
					<option selected value="<?php echo e($schedule->room_id); ?>"><?php echo e($schedule->room->name); ?> <?php echo e($schedule->room->description); ?></option>
					<?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?> <?php echo e($room->description); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</td>
		</tr>


		<tr>
			<td><label>Days</label></td>
			<td><input type="checkbox" value="M" name="days[]">M  
				<input type="checkbox" value="T" name="days[]" style="margin-left: 20px">T
				<input type="checkbox" value="W" name="days[]" style="margin-left: 20px">W
				<input type="checkbox" value="Th" name="days[]" style="margin-left: 20px">Th
				<input type="checkbox" value="F" name="days[]" style="margin-left: 20px">F
			</td>
			<td><input type="checkbox" value="M" name="day[]">M  
				<input type="checkbox" value="T" name="day[]" style="margin-left: 20px">T
				<input type="checkbox" value="W" name="day[]" style="margin-left: 20px">W
				<input type="checkbox" value="Th" name="day[]" style="margin-left: 20px">Th
				<input type="checkbox" value="F" name="day[]" style="margin-left: 20px">F
			</td>
		</tr>

		<tr>
			<td><label>Time(From-To)</label></td>
			<td><input type="time"  name="start_time_AM"
       min="06:00" max="18:00" required>
			
				<input type="time" name="end_time_AM"
       min="06:00" max="18:00" required>
			</td>

			<td><input type="time"  name="start_time_AMA"
       min="06:00" max="18:00" >
			
				<input type="time" name="end_time_AMA"
       min="06:00" max="18:00" >
			</td>

			
		</tr>
		<tr>
			<td><label>Time(From-To)</label></td>
			<td><input type="time" name="start_time_PM"
       >
			
				<input type="time" id="appt" name="end_time_PM"
        >
			</td>
			<td><input type="time" name="start_time_PMA"
        >
			
				<input type="time" id="appt" name="end_time_PMA"
        >
			</td>

			
		</tr>
		
		<tr>
			
		<div class="form-group">
			<td><a href="<?php echo e(route('schedules.index')); ?>" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/schedules/edit.blade.php ENDPATH**/ ?>