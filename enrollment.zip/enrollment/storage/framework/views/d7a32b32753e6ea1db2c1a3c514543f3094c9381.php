<?php $__env->startSection('content'); ?>
	  <div class="content-wrapper">
        <h1 class="page-title">Information</h1>
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Data table</h2>
                <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <div class="row">
                    <div class="col-12">
                        <table  class="table table-striped" style="width:100%;">
				<tr>
					<td><strong>ID:</strong></td>
					<td><?php echo e($reservation->id); ?></td>
				</tr>
	
				
	
				<tr>
					<td><strong>Name:</strong></td>
					<td> <?php echo e($reservation->student->fullname); ?></td>
				</tr>
	
				
	
				<tr>
					<td><strong>Email:</strong></td>
					<td><?php echo e($reservation->student->email); ?></td>
				</tr>

				<tr>
					<td><strong>Course:</strong></td>
					<td><?php echo e($reservation->course->name); ?></td>
				</tr>
				<tr>
					<td><strong>Address:</strong></td>
					<td> <?php echo e($reservation->student->fulladdress); ?></td>
				</tr>
				<tr>
					
					<td><strong>Mobile No:</strong></td>
					<td><?php echo e($reservation->student->mobile); ?></td>
				
				</tr>
		

			
				
			
			<tr>
			<td><a href="<?php echo e(route('reservation.index')); ?>" class="btn btn-sm btn-success">back</a></td>
		<td>	<form action="<?php echo e(route('enrollment.store')); ?>" method="POST">
				<input type="hidden" name="user_id" value="<?php echo e($reservation->student->id); ?>">
				<?php echo csrf_field(); ?>
				<button class="btn btn-primary">Enroll</button>
			</form></td>
		</tr>

</table>
</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/reservation/show.blade.php ENDPATH**/ ?>