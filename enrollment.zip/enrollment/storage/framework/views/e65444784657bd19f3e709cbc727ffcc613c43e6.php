<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
     
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('courses.update',$course->id)); ?>">
		
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
	<h2>Course</h2>
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="name" size="35" value="<?php echo e($course->name); ?>" required></td>

		</tr>
		<tr>
			<td><label>Type</label></td>
			<td><input type="text" name="types" size="35" required value="<?php echo e($course->types); ?>"><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description" size="35" value="<?php echo e($course->description); ?>"></td>
		</tr>		
		
		<tr>
			
		<div class="form-group">
		<td><a href="<?php echo e(route('courses.index')); ?>" class="btn btn-sm btn-success">Back</a></td>
		<td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>
		</td>

		</div>
	
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/courses/edit.blade.php ENDPATH**/ ?>