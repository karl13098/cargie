<?php $__env->startSection('content'); ?>



    <div class="content-wrapper dataTables_wrapper container-fluid dt-bootstrap4la" >
       


        <!-- <h1 class="pull-right">
           <a class="btn btn-primary pull-right" href="" style="margin-top: -10px;margin-bottom: 5px">Enroll Student</a>
        </h1>-->
          <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
        
        
        <div class="card" >
            <div class="card-body">
                <h2 class="card-title">Reservation <a class="btn btn-success" href="<?php echo e(route('students.create')); ?>" style="margin-left: 800px">Create New</a></h2>
               
               
                
                <div class="row">
                    <div class="col-12" >

                        <table id="order-listing"  class="table table-striped" style="width:100%;" data-page-length='25' >
                            <thead>
                            <tr>
                                
                                <th>Name</th>
                                <th>Email</th>
                                <th>Course</th>
                                <th>Scholarship</th>
                               
                                
                               
                                <th>Actions</th>
                            
                                
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               
                                <td><?php echo e($reservation->student->fullname); ?></td>
                                <td><?php echo e($reservation->student->email); ?></td>
                                <td><?php echo e($reservation->course->name); ?></td>
                                <td><?php echo e($reservation->scholarship->name); ?></td>
                                
                               


                                <td>  
                                     <form  action="<?php echo e(route('reservations.destroy',$reservation->id)); ?>" method="POST">
                                    
                                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('reservations.show',$reservation->id)); ?>">VIEW</a>
                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(route('reservations.edit',$reservation->id)); ?>">EDIT</a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                              
                                    
                <button  class="btn btn-outline-danger" onclick=" return confirm('Are you sure?')" 
                     >DELETE</button>
                </form>
           
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                            <tfoot><script>
 
</script>
</tfoot>
                        </table>


                        

                    </div>
                </div>
            </div>
        </div>
    </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/reservations/index.blade.php ENDPATH**/ ?>