<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        <h1 class="page-title">School Fees</h1>
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('tuitionfees.update',$tuitionfee->id)); ?>">
		
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
	<div class="form-group">
	<table table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr><td><label>Course</label></td>
			<td><select class="form-control" name="course" style="width: 400px" >
					
					<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($course->id == $tuitionfee->course->id): ?>

						<option selected value="<?php echo e($tuitionfee->course_id); ?>"><?php echo e($course->name); ?> <?php echo e($course->types); ?></option>
					<?php else: ?>
						
					<?php endif; ?>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tr>
		<tr>
			<td><label>Enrollment Fee:</label></td>
			<td><input type="number" name="enrollment_fee" size="50" value="<?php echo e($tuitionfee->enrollment_fee); ?>" required></td>
		</tr>

		<tr>
			<td><label>Tuition Fee:</label></td>
			<td><input type="number" name="tuition_fee" size="50" value="<?php echo e($tuitionfee->tuition_fee); ?>" required></td>
		</tr>

		<tr>
			<td><label>laboratory Fee:</label></td>
			<td><input type="number" name="laboratory_fee" size="50" value="<?php echo e($tuitionfee->laboratory_fee); ?>" required></td>
		</tr>

		<tr>
			<td><label>Records, Registration, T O R:</label></td>
			<td><input type="number" name="registration" size="50" value="<?php echo e($tuitionfee->registration); ?>" required></td>
		</tr>

		<tr>
			<td><label>Assessment Fee:</label></td>
			<td><input type="number" name="assessment_fee" value="<?php echo e($tuitionfee->assessment_fee); ?>" size="50" required></td>
		</tr>

		
		<tr>
			<td>
				<a href="<?php echo e(route('tuitionfees.index')); ?>" class="btn btn-sm btn-success">Back</a>
			</td><td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>

		</td>

	</table>
</div>

</form>
</div>
			</div>
		</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/tuitionfees/edit.blade.php ENDPATH**/ ?>