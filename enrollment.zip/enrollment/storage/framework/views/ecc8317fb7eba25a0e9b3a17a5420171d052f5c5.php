<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('sections.store')); ?>">
		
		<?php echo csrf_field(); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="name" size="35" required><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description"  size="50"></td>
		</tr>

		<tr>
			<td><label>Teacher</label></td>

			<td>
				
				<select class="form-control" name="teacher" style="width: 300px">
					<option value="">--Select--</option>
					<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->fullname); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select><sup class="text-danger">*</sup>

			</td>
		</tr>
		
		<tr>
			
		<div class="form-group">
			<td><a href="<?php echo e(route('sections.index')); ?>" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Create</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/sections/create.blade.php ENDPATH**/ ?>