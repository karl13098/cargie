<!DOCTYPE html>
<html lang="en">



<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Enrollment System</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo e(asset('node_modules/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css')); ?>">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="<?php echo e(asset('node_modules/rickshaw/rickshaw.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/chartist/dist/chartist.min.css')); ?>" />
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- endinject -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.html')); ?>" />
</head>
<body class="sidebar-dark">
<!-- partial:partials/_settings-panel.html -->
<div class="settings-panel">
    <ul class="nav nav-tabs" id="setting-panel" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="layouts-tab" data-toggle="tab" href="#layouts-section" role="tab" aria-controls="layouts-section" aria-expanded="true"><i class="mdi mdi-settings"></i></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section"><i class="mdi mdi-account"></i></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="close-button" href="#"><i class="mdi mdi-window-close"></i></a>
        </li>
    </ul>
    <div class="tab-content" id="setting-content">
        <div class="tab-pane fade show active" id="layouts-section" role="tabpanel" aria-labelledby="layouts-tab">
            <div class="color-tiles">
                <div class="tiles primary" id="primary-theme"></div>
                <div class="tiles success" id="success-theme"></div>
                <div class="tiles warning" id="warning-theme"></div>
                <div class="tiles danger" id="danger-theme"></div>
                <div class="tiles pink" id="pink-theme"></div>
                <div class="tiles info" id="info-theme"></div>
                <div class="tiles dark" id="dark-theme"></div>
                <div class="tiles light" id="light-theme"></div>
            </div>
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle btn-block mb-4" type="button" id="sidebar-color" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Sidebar Mode
                </button>
                <div class="dropdown-menu" aria-labelledby="sidebar-color">
                    <a class="dropdown-item" href="#" id="side-theme-light">Light</a>
                    <a class="dropdown-item" href="#" id="side-theme-dark">Dark</a>
                </div>
            </div>
            <div class="dropdown d-none d-md-block">
                <button class="btn btn-secondary dropdown-toggle btn-block" type="button" id="Layouts-type" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Layouts
                </button>
                <div class="dropdown-menu" aria-labelledby="Layouts-type">
                    <a class="dropdown-item" href="#" id="boxed-layout-view">Boxed</a>
                    <a class="dropdown-item" href="#" id="compact-layout-view">Compact menu</a>
                    <a class="dropdown-item" href="#" id="icon-only-layout-view">Icon Menu</a>
                    <a class="dropdown-item" href="#" id="rtl-layout-view">RTL</a>
                    <a class="dropdown-item" href="#" id="hidden-menu-1-layout-view">Hidden Menu 1</a>
                    <a class="dropdown-item" href="#" id="hidden-menu-2-layout-view">Hidden Menu 2</a>
                </div>
            </div>
        </div>
        <!-- layout section tabends -->
        <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-tab">
            <ul class="chat-list">
                <li class="list active">
                    <div class="profile"><img src="/images/tes.png" alt=""><span class="online"></span></div>
                    <div class="info">
                        <p>Admin</p>
                        <p>Available</p>
                    </div>
                </li>
                <li class="list">
                    <div class="profile"><img src="http://via.placeholder.com/47x47" alt=""><span class="online"></span></div>
                    <div class="info">
                        <p>Admin</p>
                        <p>Available</p>
                    </div>
                </li>
                <li class="list">
                    <div class="profile"><img src="http://via.placeholder.com/47x47" alt=""></div>
                    <div class="info">
                        <p>Admin</p>
                        <p>Available</p>
                    </div>
                </li>
                <li class="list">
                    <div class="profile"><img src="http://via.placeholder.com/47x47" alt=""><span class="ofline"></span></div>
                    <div class="info">
                        <p>Admin</p>
                        <p>Available</p>
                    </div>
                </li>
                <li class="list">
                    <div class="profile"><img src="http://via.placeholder.com/47x47" alt=""><span class="online"></span></div>
                    <div class="info">
                        <p>Admin</p>
                        <p>Available</p>
                    </div>
                </li>
                <li class="list">
                    <div class="profile"><img src="http://via.placeholder.com/47x47" alt=""></div>
                    <div class="info">
                        <p>Admin</p>
                        <p>Available</p>
                    </div>
                </li>
            </ul>
        </div>
        <!-- chat section tabends -->
    </div>
</div>
<!-- partial -->
<div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar navbar-light col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper">
            <a class="navbar-brand brand-logo" href="<?php echo e(URL::to('/home')); ?>"><img src="/images/tes.png" class="img-responsive" alt="Logo"></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center">
            <button class="navbar-toggler navbar-toggler align-self-center mr-2" type="button" data-toggle="minimize"  >
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-brand brand-logo hide"></span>
            </button>
            <!--<div class="btn-group d-none d-sm-block">
                <button type="button" class="btn btn-secondary btn-sm text-muted border-0 dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Dropdown
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Separated link</a>
                </div>
            </div>
           <!-- <form class="form-inline mt-2 ml-3 mt-md-0 d-none d-sm-block">
                <div class="input-group solid">
                    <span class="input-group-addon"><i class="mdi mdi-magnify"></i></span>
                    <input type="text" class="form-control">
                </div>
            </form>
        -->
            <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>
            <ul class="navbar-nav ml-auto"> 
                <li class="nav-item dropdown ">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <i class="mdi mdi-account"> </i><span class="caret"></span>
                    </a>

                    <div class="dropdown-menu " aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <div class="row row-offcanvas row-offcanvas-right">
            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <div class="user-info">
                    <div class="profile">
                        <img src="/images/admin.png" alt="">
                    </div>
                    <div class="details">
                        <p class="user-name">Admin</p>
                        <p class="designation"></p>
                    </div>
                </div>
                <ul class="nav">
                    <!--main pages start-->
                    <li class="nav-item nav-category">
                        <span class="nav-link">Main</span>
                    </li>



                    <!-- <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#advancedSubmenus" aria-expanded="false" aria-controls="advancedSubmenus">
                            <i class="mdi mdi-gauge menu-icon"></i>
                            <span class="menu-title">Reservations</span>
                            <i class="mdi mdi-chevron-down menu-arrow"></i>
                        </a>
                        <div class="collapse" id="advancedSubmenus">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item">
                                    <a class="nav-link" href="">Pending</a>
                                    <a class="nav-link" href="">Registration</a>
                                    <a class="nav-link" href="">Personal Information</a>
                                </li>

                            </ul>
                        </div>
                    </li>
                    -->
                    <!--<li class="nav-item">
                        <a class="nav-link" href="">
                            <i class="mdi mdi-gauge menu-icon"></i>
                            <span class="menu-title">Students</span>
                        </a>
                    </li>
                --> <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(URL::to('/home')); ?>">
                            <i class=" menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                            
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(URL::to('/reservations')); ?>">
                            <i class="mdi mdi-puzzle menu-icon"></i>
                            <span class="menu-title">Registration</span>
                            <span class="badge badge-danger badge-pill ml-auto">New</span>
                        </a>
                    </li>

                    

                   <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#advancedSubmenus" aria-expanded="false" aria-controls="advancedSubmenus">
                            <i class="mdi mdi-gauge menu-icon"></i>
                            <span class="menu-title">Students Masterlist</span>
                            <i class="mdi mdi-chevron-down menu-arrow"></i>
                        </a>
                        <div class="collapse" id="advancedSubmenus">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('students.index')); ?>">Students</a>
                                    <a class="nav-link" href="<?php echo e(route('studentschedules.index')); ?>">All Students</a>
                                    <a class="nav-link" href="<?php echo e(route('studentrequirements.index')); ?>">Student Requirement</a>
                                </li>

                            </ul>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('schedules.index')); ?>">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">Schedule Module</span>
                            
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('tuitionfees.index')); ?>">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">School Fees</span>
                            
                        </a>
                    </li>

                     <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('fees.index')); ?>">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">Fees</span>
                            
                        </a>
                    </li>

                     <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">Payment</span>
                            
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('scholarships.index')); ?>">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">Scholarship</span>
                            
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('sections.index')); ?>">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">Section</span>
                            
                        </a>
                    </li>

                     <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('school_years.index')); ?>">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">School Year</span>
                            
                        </a>
                    </li>
                   
                    



                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('rooms.index')); ?>">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">Room</span>
                            
                        </a>
                    </li>















                   <!-- <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#layoutsSubmenu" aria-expanded="false" aria-controls="layoutsSubmenu">
                            <i class="mdi mdi-arrow-expand-all menu-icon"></i>
                            <span class="menu-title">Transaction</span>
                            <i class="mdi mdi-chevron-down menu-arrow"></i>
                        </a>
                        <div class="collapse" id="layoutsSubmenu">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(URL::to('/tutionfee')); ?>">Tuition free</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="pages/layout/rtl-layout.html">Result</a>
                                </li>

                            </ul>
                        </div>
                    </li>-->
                    
                     <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('courses.index')); ?>">
                            <i class="mdi mdi-format-list-bulleted menu-icon"></i>
                            <span class="menu-title">Course</span>
                            
                        </a>
                    </li>
                    <!--                    
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#sidebar_layouts" aria-expanded="false" aria-controls="sidebar_layouts">
                            <i class="mdi mdi-format-list-bulleted menu-icon"></i>
                            <span class="menu-title">Course</span>
                            <i class="mdi mdi-chevron-down menu-arrow"></i>
                        </a>
                        <div class="collapse" id="sidebar_layouts">
                            <ul class="nav flex-column sub-menu">
                                 <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('courses.index')); ?>">Add Course</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(URL::to('/EventsManagementServices')); ?>">EVENTS MANAGEMENT SERVICES NC III</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(URL::to('/Bookkeeping')); ?>">BOOKKEEPING NC III</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(URL::to('/FoodAndBeveragesServices')); ?>">FOOD AND BEVERAGE SERVICES NC III</a>
                                </li>
                               
                            </ul>
                        </div>
                    </li>
                    <!--main pages end-->

                     <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('teacher.index')); ?>">
                            <i class="mdi mdi-repeat menu-icon"></i>
                            <span class="menu-title">Teacher</span>
                            
                        </a>
                    </li>



                    <i class="mdi mdi-chevron-down menu-arrow"></i>
                    </a>
                    <div class="collapse" id="mapsSubmenu">
                        <ul class="nav flex-column sub-menu">
                            <li class="nav-item">
                                <a class="nav-link" href="pages/maps/mapeal.html">Mapeal</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="pages/maps/vector-map.html">Vector map</a>
                            </li>
                        </ul>
                    </div>
                    </li>
                    
                    <!--
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#advancedSubmenu" aria-expanded="false" aria-controls="advancedSubmenu">
                            <i class="mdi mdi-repeat menu-icon"></i>
                            <span class="menu-title">Teacher</span>
                            <i class="mdi mdi-chevron-down menu-arrow"></i>
                        </a>
                        <div class="collapse" id="advancedSubmenu">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('teacher.index')); ?>">All Teacher</a>
                                    <a class="nav-link" href="<?php echo e(route('teacher.create')); ?>">Add Teacher</a>
                                </li>

                            </ul>
                        </div>
                    </li>-->
                </ul>




            </nav>

            <!-- partial -->
            
                    <?php echo $__env->yieldContent('content'); ?>

    


            <!-- content-wrapper ends -->
            <!-- partial:partials/_footer.html -->
            <footer class="footer">
                <div class="container-fluid clearfix">
            <span class="float-right">
                <a href="#">Admin</a> &copy; 2019
            </span>
                </div>
            </footer>
            <!-- partial -->
        </div>
        <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->

<!-- plugins:js -->
<script src="<?php echo e(asset('node_modules/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js')); ?>"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<script src="<?php echo e(asset('node_modules/flot/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/flot/jquery.flot.resize.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/flot/jquery.flot.categories.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/flot/jquery.flot.pie.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/rickshaw/vendor/d3.v3.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/rickshaw/rickshaw.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/chartist/dist/chartist.min.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/chartist-plugin-legend/chartist-plugin-legend.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/chart.js/dist/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
<!-- End plugin js for this page-->
<script src="<?php echo e(asset('node_modules/datatables.net/js/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/datatables.net-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table.js')); ?>"></script>
<!-- inject:js -->
<script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
<script src="<?php echo e(asset('js/hoverable-collapse.js')); ?>"></script>
<script src="<?php echo e(asset('js/misc.js')); ?>"></script>
<script src="<?php echo e(asset('js/settings.js')); ?>"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="<?php echo e(asset('js/dashboard_1.js')); ?>"></script>
<!-- End custom js for this page-->
<script type = 'text/javascript' src="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js')); ?>"></script>
</body>


<!-- Mirrored from www.urbanui.com/salt/jquery/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Dec 2017 12:32:50 GMT -->
</html>
<?php /**PATH C:\laragon\www\enrollment\resources\views/layout.blade.php ENDPATH**/ ?>