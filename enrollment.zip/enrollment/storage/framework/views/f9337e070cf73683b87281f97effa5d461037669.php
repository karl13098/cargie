<?php $__env->startSection('content'); ?>
	



	<div class="content-wrapper">
        
        <div class="row">
                   
              
            <div class="card-body">
               
              <p class="alert-success"></p>
                     <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

                  
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('sections.update',$section->id)); ?>">
		
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		
	<div class='form-group'>
	 <table id="order-listing" class="table table-striped" style="width:100%;">
		
		<tr>
			<td><label>Name</label></td>
			<td><input type="text" name="name" size="35" required value="<?php echo e($section->name); ?>"><sup class="text-danger">*</sup></td>
		</tr>
		<tr>
			<td><label>Description</label></td>
			<td><input type="text" name="description"  size="50" value="<?php echo e($section->description); ?>"></td>
		</tr>

		<tr><td><label>Teacher</label></td>
			<td><select class="form-control" name="teacher" style="width: 300px">
					
					<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($teacher->id == $section->teacher_id): ?>

						<option selected value="<?php echo e($section->teacher->id); ?>"><?php echo e($section->teacher->fullname); ?></option>
					<?php else: ?>
						<option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->fullname); ?></option>
						
					<?php endif; ?>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

			</td>
		</tr>
			
		<div class="form-group">
			<td><a href="<?php echo e(route('sections.index')); ?>" class="btn btn-sm btn-success">Back</a></td><td>
			<button type="submit" class="btn btn-sm btn-primary">Save</button>

		</div>
	</td>
</tr>

	</table>
</div>

</form>
			</div>
		</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/sections/edit.blade.php ENDPATH**/ ?>