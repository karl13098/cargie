<?php $__env->startSection('content'); ?>
	


	<div class="content-wrapper">
        <h1 class="page-title">Enrollment Form 
        	<select class="flex-column" name="reservation_id" style="margin-left: 500px">
					<option style="" value="">--Select--</option>
					<?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($reservation->id); ?>" ><?php echo e($reservation->fullname); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>



        </h1> 	
				
        <div class="card">
                   
              
            <div class="card-body">
               
              <p class="alert-success">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($e); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-12">
	<form class="forms-sample" method="POST" action="<?php echo e(route('enrollments.store')); ?>">
		
		<?php echo csrf_field(); ?>
	<div class='form-group'>
	 <table id="order-listing" class="table tab-content" >
	
		
		
		
			

		<tr>
			<td>EnrollmentID<input type="text" name="id"></td>
			<td>Section<input type="text" name=""></td>

		</tr>

		<tr>
			<td>Name<input style="margin-left: 45px" type="text" name="" id="reservation_id" readonly></td>
			<td>Academic Year<input type="text" name="" style="margin-left: 2px"></td>
		</tr>

		<tr>
			<td>Course<input type="text" name="course" style="margin-left: 38px"></td>
			<td>Scholarship<input type="text55555" name=""></td>
		</tr>



	</table>
</div>

</form>
			</div>
			</div>
		</p>
		</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\enrollment\resources\views/enrollments/create.blade.php ENDPATH**/ ?>